import os, sys

url = sys.argv[1]
key = [int(b) for b in os.urandom(16)]
enc = [(b ^ key[i % len(key)]) for i, b in enumerate(url.encode('utf-8'))]

def to_java_bytes(arr):
    parts = []
    for v in arr:
        if v > 127:
            v = v - 256
        parts.append(str(v))
    return '{' + ', '.join(parts) + '}'

with open('/tmp/xor_encoded_url.txt', 'w') as f:
    f.write(to_java_bytes(enc))
with open('/tmp/xor_key.txt', 'w') as f:
    f.write(to_java_bytes(key))

print("XOR encode OK, key length:", len(key))
