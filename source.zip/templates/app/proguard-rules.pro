# ── Keep WebView & JavaScript bridge ─────────────────────────────────────────
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class * extends android.webkit.WebViewClient
-keep class * extends android.webkit.WebChromeClient

# ── Keep app entry point ──────────────────────────────────────────────────────
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application

# ── Obfuscate everything else ─────────────────────────────────────────────────
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# ── Remove logging (sembunyikan debug info) ───────────────────────────────────
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}
