package {{PKG}};

import android.Manifest;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.view.MotionEvent;
import android.view.ViewGroup;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private SwipeRefreshLayout swipeRefreshLayout;

    public static class DampedSwipeRefreshLayout extends SwipeRefreshLayout {
        private static final float DAMPING_FACTOR = 0.35f;

        private float downY = 0f;
        private boolean tracking = false;

        public DampedSwipeRefreshLayout(Context context) {
            super(context);
        }

        public DampedSwipeRefreshLayout(Context context, android.util.AttributeSet attrs) {
            super(context, attrs);
        }

        private MotionEvent dampen(MotionEvent ev) {
            int action = ev.getActionMasked();

            if (action == MotionEvent.ACTION_DOWN) {
                downY = ev.getY();
                tracking = true;
                return ev;
            }

            if (!tracking) return ev;

            if (action == MotionEvent.ACTION_MOVE) {
                float rawDelta = ev.getY() - downY;
                if (rawDelta > 0) {
                    float dampedDelta = rawDelta * DAMPING_FACTOR;
                    MotionEvent copy = MotionEvent.obtain(ev);
                    copy.setLocation(ev.getX(), downY + dampedDelta);
                    return copy;
                }
                return ev;
            }

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                tracking = false;
            }
            return ev;
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            MotionEvent d = dampen(ev);
            boolean result = super.onInterceptTouchEvent(d);
            if (d != ev) d.recycle();
            return result;
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            MotionEvent d = dampen(ev);
            boolean result = super.onTouchEvent(d);
            if (d != ev) d.recycle();
            return result;
        }
    }

    private Set<String> blockedUrls = new HashSet<>();
    private static final String BLOCKED_URLS_SOURCE = "https://raw.githubusercontent.com/ZalRyuichi/Ryuichi-App/refs/heads/main/blok_url.json";

    private static final String URL_MODE = "{{URL_MODE}}";

    private static final String OFFLINE_HTML = """
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
  <title>XYZXRAT</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Share+Tech+Mono&family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }

    :root {
      --bg:    #03080f;
      --s:     #060d18;
      --c:     #091220;
      --b:     #132035;
      --b2:    #1a2d47;
      --cyan:  #22d3ee;
      --blue:  #3b82f6;
      --blue2: #60a5fa;
      --red:   #f87171;
      --amber: #fbbf24;
      --white: #f0f6ff;
      --t:     #d4e8ff;
      --t2:    #4a6a90;
      --mono:  'Share Tech Mono', monospace;
      --head:  'Orbitron', sans-serif;
      --title: 'Rajdhani', sans-serif;
    }

    html, body {
      width:100%; min-height:100vh;
      background: var(--bg);
      font-family: var(--mono);
      color: var(--t);
      overflow-x: hidden;
      -webkit-font-smoothing: antialiased;
    }

    .bg-layer { position:fixed; inset:0; z-index:0; pointer-events:none; }
    .bg-gradient {
      background:
        radial-gradient(ellipse 80% 50% at 50% 110%, rgba(0,80,180,0.20) 0%, transparent 70%),
        radial-gradient(ellipse 60% 40% at 15% 10%,  rgba(0,180,255,0.06) 0%, transparent 60%),
        radial-gradient(ellipse 50% 40% at 85% 80%,  rgba(34,211,238,0.04) 0%, transparent 60%),
        var(--bg);
    }
    .bg-grid {
      background-image:
        linear-gradient(rgba(0,200,255,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,200,255,0.035) 1px, transparent 1px);
      background-size: 48px 48px;
    }
    .bg-diagonal {
      background: repeating-linear-gradient(
        -52deg, transparent 0px, transparent 100px,
        rgba(0,150,255,0.018) 100px, rgba(0,150,255,0.018) 101px
      );
    }
    .bg-noise {
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
      background-size: 200px; opacity:.022;
    }
    .bg-vignette {
      background: radial-gradient(ellipse 100% 100% at 50% 50%, transparent 55%, rgba(0,0,0,0.55) 100%);
    }

    .scanline {
      position:fixed; left:0; right:0; height:3px; z-index:1; pointer-events:none;
      background: linear-gradient(90deg, transparent, rgba(34,211,238,0.13), transparent);
      animation: scan 9s linear infinite;
    }
    @keyframes scan { 0%{top:-3px} 100%{top:100vh} }

    .hud { position:fixed; width:44px; height:44px; z-index:2; pointer-events:none; border-color:rgba(34,211,238,0.22); border-style:solid; }
    .hud-tl { top:14px; left:14px;  border-width:2px 0 0 2px; }
    .hud-tr { top:14px; right:14px; border-width:2px 2px 0 0; }
    .hud-bl { bottom:14px; left:14px;  border-width:0 0 2px 2px; }
    .hud-br { bottom:14px; right:14px; border-width:0 2px 2px 0; }

    .topbar {
      position:fixed; top:0; left:0; right:0; height:44px; z-index:10;
      display:flex; align-items:center; justify-content:space-between;
      padding:0 60px;
      background: linear-gradient(180deg, rgba(3,8,15,0.95) 0%, rgba(3,8,15,0) 100%);
      backdrop-filter: blur(2px);
    }
    .topbar-logo {
      font-family: var(--title); font-size:15px; letter-spacing:4px;
      color:var(--cyan); text-shadow:0 0 12px rgba(34,211,238,0.5); opacity:.85;
    }
    .topbar-tag { font-size:9px; letter-spacing:3px; color:var(--t2); text-transform:uppercase; }

    #pbar {
      position:fixed; top:0; left:0; height:2px; z-index:99;
      background: linear-gradient(90deg, var(--amber), rgba(251,191,36,0.4));
      box-shadow: 0 0 10px rgba(251,191,36,0.8), 0 0 20px rgba(251,191,36,0.3);
      width: 55%; animation: errPulse 2.4s ease-in-out infinite;
    }
    @keyframes errPulse { 0%,100%{opacity:1} 50%{opacity:0.3} }

    .particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
    .p {
      position:absolute; border-radius:50%;
      background:var(--amber); opacity:0;
      animation: rise var(--t,10s) linear var(--d,0s) infinite;
    }
    @keyframes rise {
      0%   { transform:translateY(105vh) scale(0); opacity:0; }
      8%   { opacity:0.4; }
      92%  { opacity:0.12; }
      100% { transform:translateY(-5vh) scale(1.8); opacity:0; }
    }

    .stage {
      position:relative; z-index:3; min-height:100vh;
      display:flex; flex-direction:column;
      align-items:center; justify-content:center;
      padding:80px 24px 60px;
    }

    /* ── Server icon ── */
    .server-wrap {
      position:relative; width:130px; height:130px;
      display:flex; align-items:center; justify-content:center;
      margin-bottom: 32px;
      animation: floatUp 4s ease-in-out infinite;
    }
    @keyframes floatUp { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }

    .server-ring {
      position:absolute; border-radius:50%;
      border:1px solid rgba(251,191,36,0.2);
      animation: ringExpand 2.8s ease-out infinite;
    }
    .server-ring:nth-child(1) { width:82px;  height:82px;  animation-delay:0s;   border-color:rgba(251,191,36,0.32); }
    .server-ring:nth-child(2) { width:106px; height:106px; animation-delay:0.7s; border-color:rgba(251,191,36,0.18); }
    .server-ring:nth-child(3) { width:130px; height:130px; animation-delay:1.4s; border-color:rgba(251,191,36,0.08); }
    @keyframes ringExpand {
      0%  { transform:scale(0.72); opacity:1; }
      70% { opacity:0.4; }
      100%{ transform:scale(1.12); opacity:0; }
    }

    .server-icon {
      position:relative; z-index:1;
      width:62px; height:62px;
      background: rgba(248,113,113,0.07);
      border: 1px solid rgba(248,113,113,0.3);
      border-radius:14px;
      display:flex; align-items:center; justify-content:center;
      box-shadow:
        0 0 24px rgba(248,113,113,0.15),
        0 0 60px rgba(248,113,113,0.05),
        inset 0 0 20px rgba(248,113,113,0.04);
    }
    .server-icon svg {
      width:30px; height:30px;
      animation: iconBlink 2.8s ease-in-out infinite;
    }
    @keyframes iconBlink { 0%,100%{opacity:1} 50%{opacity:0.5} }

    /* ── Badge ── */
    .err-badge {
      display:flex; align-items:center; gap:8px;
      background: rgba(251,191,36,0.07);
      border: 1px solid rgba(251,191,36,0.22);
      border-radius:100px; padding:5px 14px; margin-bottom:22px;
      font-size:10px; letter-spacing:3px; color:var(--amber);
      text-transform:uppercase;
      box-shadow: 0 0 16px rgba(251,191,36,0.08);
      animation: badgeFade 1.5s ease both;
    }
    .err-dot {
      width:6px; height:6px; border-radius:50%;
      background:var(--amber); box-shadow:0 0 6px var(--amber);
      animation: dotPulse 1.2s ease-in-out infinite;
    }
    @keyframes dotPulse { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.5);opacity:0.6} }
    @keyframes badgeFade { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }

    .main-title {
      font-family: var(--head);
      font-size: clamp(22px, 6vw, 40px);
      font-weight:700; letter-spacing:2px; text-align:center;
      color:var(--white);
      text-shadow:0 0 30px rgba(251,191,36,0.2), 0 2px 20px rgba(0,0,0,0.6);
      margin-bottom:12px;
      animation: textReveal 0.8s ease 0.2s both;
    }
    .sub-title {
      font-size:11px; letter-spacing:5px; color:var(--t2);
      text-transform:uppercase; text-align:center; margin-bottom:36px;
      animation: textReveal 0.8s ease 0.35s both;
    }
    @keyframes textReveal { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }

    /* ── Status card ── */
    .status-card {
      width:100%; max-width:380px;
      background: rgba(9,18,32,0.7);
      border: 1px solid rgba(251,191,36,0.1);
      border-radius:16px; padding:24px;
      backdrop-filter:blur(20px);
      box-shadow:
        0 0 0 1px rgba(0,0,0,0.4),
        0 20px 60px rgba(0,0,0,0.5),
        inset 0 1px 0 rgba(255,255,255,0.04);
      margin-bottom:28px;
      animation: textReveal 0.8s ease 0.5s both;
    }
    .status-row {
      display:flex; align-items:center; justify-content:space-between;
      padding:11px 0;
      border-bottom:1px solid rgba(251,191,36,0.07);
    }
    .status-row:last-child { border-bottom:none; }
    .status-label {
      font-size:10px; letter-spacing:2px; color:var(--t2);
      text-transform:uppercase; display:flex; align-items:center; gap:8px;
    }
    .status-label svg { width:13px; height:13px; stroke:var(--t2); opacity:.7; }
    .status-val { font-size:11px; letter-spacing:1px; font-family:var(--mono); }
    .status-val.err  { color:var(--red);   text-shadow:0 0 8px rgba(248,113,113,0.5); }
    .status-val.warn { color:var(--amber); text-shadow:0 0 8px rgba(251,191,36,0.4); }
    .status-val.ok   { color:#34d399;      text-shadow:0 0 8px rgba(52,211,153,0.4); }

    /* ── Progress bar maintenance ── */
    .maint-progress {
      width:100%; max-width:380px;
      margin-bottom:28px;
      animation: textReveal 0.8s ease 0.6s both;
    }
    .maint-label {
      display:flex; justify-content:space-between; align-items:center;
      font-size:9px; letter-spacing:2px; color:var(--t2);
      text-transform:uppercase; margin-bottom:8px;
    }
    .maint-label span { color:var(--amber); }
    .maint-track {
      width:100%; height:4px;
      background: rgba(251,191,36,0.1);
      border-radius:100px; overflow:hidden;
      border: 1px solid rgba(251,191,36,0.12);
    }
    .maint-fill {
      height:100%; width:0%;
      background: linear-gradient(90deg, rgba(251,191,36,0.5), var(--amber));
      border-radius:100px;
      box-shadow: 0 0 8px rgba(251,191,36,0.5);
      animation: fillProgress 3s cubic-bezier(.4,0,.2,1) 1.2s forwards;
    }
    @keyframes fillProgress { to{width:68%} }

    .desc {
      max-width:320px; text-align:center;
      font-size:12px; line-height:1.9; color:var(--t2);
      margin-bottom:36px;
      animation: textReveal 0.8s ease 0.65s both;
    }
    .desc span { color:var(--cyan); text-shadow:0 0 8px rgba(34,211,238,0.4); }
    .desc span.hi { color:var(--amber); text-shadow:0 0 8px rgba(251,191,36,0.4); }

    /* ── Button ── */
    .btn-retry {
      position:relative;
      display:flex; align-items:center; gap:10px;
      padding:13px 32px;
      background: rgba(251,191,36,0.06);
      border: 1px solid rgba(251,191,36,0.3);
      border-radius:10px;
      font-family:var(--mono); font-size:11px;
      letter-spacing:3px; text-transform:uppercase;
      color:var(--amber); cursor:pointer; overflow:hidden;
      transition: all 0.25s ease;
      animation: textReveal 0.8s ease 0.8s both;
      box-shadow: 0 0 20px rgba(251,191,36,0.06);
    }
    .btn-retry:hover {
      background: rgba(251,191,36,0.12);
      border-color: rgba(251,191,36,0.55);
      box-shadow: 0 0 30px rgba(251,191,36,0.18), 0 0 60px rgba(251,191,36,0.06);
      transform:translateY(-1px);
    }
    .btn-retry:active { transform:scale(0.97) translateY(0); }
    .btn-retry svg { width:15px; height:15px; stroke:var(--amber); }
    .btn-retry.loading svg { animation:spin 0.8s linear infinite; }
    @keyframes spin { to{transform:rotate(360deg)} }

    .btn-ripple {
      position:absolute; inset:0;
      background: linear-gradient(90deg, transparent, rgba(251,191,36,0.08), transparent);
      transform:translateX(-100%);
      animation: ripple 3.2s ease-in-out 1.5s infinite;
    }
    @keyframes ripple { 0%{transform:translateX(-100%)} 40%{transform:translateX(100%)} 100%{transform:translateX(100%)} }

    .code-strip {
      margin-top:44px;
      display:flex; flex-direction:column; align-items:center; gap:4px;
      animation: textReveal 0.8s ease 1s both;
    }
    .code-line { font-size:9px; letter-spacing:2px; color:rgba(74,106,144,0.4); font-family:var(--mono); }
    .code-line .hl  { color:rgba(34,211,238,0.32); }
    .code-line .hl2 { color:rgba(251,191,36,0.38); }

    .ver-tag {
      position:fixed; bottom:18px; left:50%; transform:translateX(-50%);
      font-size:9px; letter-spacing:4px; color:rgba(34,211,238,0.2);
      z-index:2; pointer-events:none; white-space:nowrap;
    }

    /* ── Toast ── */
    .toast-wrap {
      position:fixed; top:20px; right:16px; z-index:9999;
      display:flex; flex-direction:column; align-items:flex-end; gap:8px;
      width:calc(100% - 32px); max-width:300px; pointer-events:none;
    }
    .toast {
      width:100%; background:rgba(6,13,24,0.97);
      border-radius:12px; padding:11px 14px;
      font-size:10px; letter-spacing:.4px;
      display:flex; align-items:center; gap:10px;
      animation: toastIn .25s cubic-bezier(.34,1.56,.64,1) both;
      backdrop-filter:blur(28px); position:relative; overflow:hidden;
      border:1px solid rgba(251,191,36,0.18);
      box-shadow:0 8px 32px rgba(0,0,0,.8), 0 0 16px rgba(251,191,36,0.06);
    }
    .toast::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; border-radius:3px 0 0 3px; background:var(--amber); box-shadow:0 0 8px var(--amber); }
    @keyframes toastIn { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:translateX(0)} }
  </style>
</head>
<body>

  <div class="bg-layer bg-gradient"></div>
  <div class="bg-layer bg-grid"></div>
  <div class="bg-layer bg-diagonal"></div>
  <div class="bg-layer bg-noise"></div>
  <div class="bg-layer bg-vignette"></div>

  <div class="scanline"></div>

  <div class="hud hud-tl"></div>
  <div class="hud hud-tr"></div>
  <div class="hud hud-bl"></div>
  <div class="hud hud-br"></div>

  <div id="pbar"></div>
  <div class="particles" id="pts"></div>
  <div class="toast-wrap" id="toastWrap"></div>

  <main class="stage">

    <!-- Server icon -->
    <div class="server-wrap">
      <div class="server-ring"></div>
      <div class="server-ring"></div>
      <div class="server-ring"></div>
      <div class="server-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="stroke:var(--red);filter:drop-shadow(0 0 6px rgba(248,113,113,0.7))">
          <line x1="1" y1="1" x2="23" y2="23"/>
          <path d="M16.72 11.06A10.94 10.94 0 0119 12.55"/>
          <path d="M5 12.55a10.94 10.94 0 015.17-2.39"/>
          <path d="M10.71 5.05A16 16 0 0122.56 9"/>
          <path d="M1.42 9a15.91 15.91 0 014.7-2.88"/>
          <path d="M8.53 16.11a6 6 0 016.95 0"/>
          <circle cx="12" cy="20" r="1" fill="var(--red)" stroke="none"/>
        </svg>
      </div>
    </div>

    <!-- Badge -->
    <div class="err-badge">
      <div class="err-dot"></div>
      <span>Server Offline</span>
    </div>

    <!-- Titles -->
    <h1 class="main-title">Aplikasi Sedang Offline</h1>
    <p class="sub-title">Server Tidak Dapat Dijangkau</p>

    <!-- Status card -->
    <div class="status-card">
      <div class="status-row">
        <span class="status-label">
          <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/>
            <line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>
          </svg>
          App Server
        </span>
        <span class="status-val err">OFFLINE</span>
      </div>
      <div class="status-row">
        <span class="status-label">
          <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s-8-4.5-8-11.8A8 8 0 0112 2a8 8 0 018 8.2c0 7.3-8 11.8-8 11.8z"/>
            <circle cx="12" cy="10" r="3"/>
          </svg>
          Database
        </span>
        <span class="status-val err">UNREACHABLE</span>
      </div>
      <div class="status-row">
        <span class="status-label">
          <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/>
          </svg>
          Maintenance
        </span>
        <span class="status-val warn">IN PROGRESS</span>
      </div>
      </div>
    </div>

    <!-- Maintenance progress -->
    <div class="maint-progress">
      <div class="maint-label">
        <span>Progress Maintenance</span>
        <span id="pctVal">0%</span>
      </div>
      <div class="maint-track">
        <div class="maint-fill" id="maintFill"></div>
      </div>
    </div>

    <!-- Retry button -->
    <button class="btn-retry" id="retryBtn" onclick="doRetry()">
      <div class="btn-ripple"></div>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" id="retryIcon">
        <polyline points="23 4 23 10 17 10"/>
        <path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/>
      </svg>
      <span id="retryText">Cek Ulang Server</span>
    </button>

    <!-- Code decoration -->
    <div class="code-strip">
      <div class="code-line"><span class="hl2">ERR_APP_SERVER_OFFLINE</span></div>
    </div>

  </main>

  <script>    
    (function(){
      const c=document.getElementById('pts');
      for(let i=0;i<24;i++){
        const p=document.createElement('div'); p.className='p';
        const sz=Math.random()*1.5+0.8;
        p.style.cssText=`width:${sz}px;height:${sz}px;left:${Math.random()*100}%;--t:${8+Math.random()*10}s;--d:${-Math.random()*10}s;`;
        c.appendChild(p);
      }
    })();

    (function(){
      let v=0;
      const el=document.getElementById('pctVal');
      const iv=setInterval(()=>{
        v+=2; el.textContent=v+'%';
        if(v>=68) clearInterval(iv);
      }, 60);
    })();

    let retries=0;
    function doRetry(){
      const btn=document.getElementById('retryBtn');
      const txt=document.getElementById('retryText');
      btn.classList.add('loading'); btn.disabled=true;
      txt.textContent='Memeriksa...';
      setTimeout(()=>{
        retries++;
        btn.classList.remove('loading'); btn.disabled=false;
        txt.textContent='Cek Ulang Server';
        showToast();
      }, 2000);
    }

    function showToast(){
      const w=document.getElementById('toastWrap');
      const t=document.createElement('div'); t.className='toast';
      t.innerHTML=`
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span>Server Masih Offline.</span>
      `;
      w.appendChild(t);
      setTimeout(()=>t.remove(), 3500);
    }
  </script>
</body>
    </html>
        """;
    private static final byte[] ENCODED_URL = {{ENCODED_URL}};
    private static final byte[] XOR_KEY     = {{XOR_KEY}};

    private static String decodeUrl() {
        byte[] out = new byte[ENCODED_URL.length];
        for (int i = 0; i < ENCODED_URL.length; i++) {
            out[i] = (byte) (ENCODED_URL[i] ^ XOR_KEY[i % XOR_KEY.length]);
        }
        return new String(out, java.nio.charset.StandardCharsets.UTF_8);
    }

    private static final String ORIGINAL_PKG   = "{{PKG}}";
    private static final String ORIGINAL_LABEL = "{{APP_NAME}}";

    private void checkPackageIntegrity() {
        String currentPkg = getPackageName();
        if (!currentPkg.equals(ORIGINAL_PKG)) {
            killApp();
            return;
        }
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                .getApplicationInfo(currentPkg, 0);
            String currentLabel = getPackageManager().getApplicationLabel(ai).toString();
            if (!currentLabel.equals(ORIGINAL_LABEL)) {
                killApp();
                return;
            }
        } catch (Exception e) {
            killApp();
        }
    }

    private void killApp() {
        Toast.makeText(this, "Terdeteksi Lemer Ngerename\uD83D\uDE02", Toast.LENGTH_LONG).show();
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            finishAffinity();
            android.os.Process.killProcess(android.os.Process.myPid());
        }, 2000);
    }

    private ValueCallback<Uri[]> fileUploadCallback;
    private ActivityResultLauncher<Intent> filePickerLauncher;

    public class BlobBridge {
        @JavascriptInterface
        public void onBlobReady(String dataUrl, String fileName) {
            try {
                int semiIdx = dataUrl.indexOf(';');
                int commaIdx = dataUrl.indexOf(',');
                String mime = dataUrl.substring(5, semiIdx > 0 ? semiIdx : commaIdx);
                final String base64 = dataUrl.substring(commaIdx + 1).replaceAll("\\s+", "");
                final String finalName = (fileName != null && !fileName.trim().isEmpty())
                    ? fileName.trim()
                    : "download_" + System.currentTimeMillis();
                final String finalMime = (mime != null && !mime.isEmpty()) ? mime : "application/octet-stream";
                new Thread(() -> {
                    try {
                        byte[] bytes = android.util.Base64.decode(base64,
                            android.util.Base64.NO_WRAP | android.util.Base64.NO_PADDING);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            ContentValues cv = new ContentValues();
                            cv.put(MediaStore.Downloads.DISPLAY_NAME, finalName);
                            cv.put(MediaStore.Downloads.MIME_TYPE, finalMime);
                            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                            if (uri == null) throw new Exception("Gagal buat file di MediaStore");
                            try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
                                if (os == null) throw new Exception("Gagal buka output stream");
                                os.write(bytes);
                            }
                        } else {
                            java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                            if (!dir.exists()) dir.mkdirs();
                            java.io.File file = new java.io.File(dir, finalName);
                            java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
                            fos.write(bytes);
                            fos.close();
                            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
                        }
                        runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Tersimpan: " + finalName, Toast.LENGTH_SHORT).show());
                    } catch (Exception ex) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Gagal simpan blob: " + ex.getMessage(), Toast.LENGTH_LONG).show());
                    }
                }).start();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "Gagal proses blob: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    public class ClipboardBridge {
        private final Context ctx;
        ClipboardBridge(Context c) { ctx = c; }

        @JavascriptInterface
        public void copy(String text) {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("copied", text));
                runOnUiThread(() ->
                    Toast.makeText(ctx, "Disalin ke clipboard", Toast.LENGTH_SHORT).show()
                );
            }
        }

        @JavascriptInterface
        public String paste() {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip()
                    && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence text = cm.getPrimaryClip().getItemAt(0).getText();
                return text != null ? text.toString() : "";
            }
            return "";
        }
    }

    public class AndroidDeviceBridge {
        @JavascriptInterface
        public String getBuildId() {
            return android.os.Build.ID + "-" + android.os.Build.SERIAL.hashCode();
        }

        @JavascriptInterface
        public String getModel() {
            return android.os.Build.MODEL;
        }

        @JavascriptInterface
        public String getManufacturer() {
            return android.os.Build.MANUFACTURER;
        }

        @JavascriptInterface
        public int getSdkInt() {
            return android.os.Build.VERSION.SDK_INT;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        checkPackageIntegrity();

        setContentView(R.layout.activity_main);

        webView      = findViewById(R.id.webView);

        ViewGroup parent = (ViewGroup) webView.getParent();
        int webViewIndex = parent.indexOfChild(webView);
        parent.removeView(webView);

        swipeRefreshLayout = new DampedSwipeRefreshLayout(this);
        swipeRefreshLayout.setLayoutParams(new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        swipeRefreshLayout.setColorSchemeColors(0xFF22D3EE);
        swipeRefreshLayout.setProgressBackgroundColorSchemeColor(0xFF091220);
        swipeRefreshLayout.addView(webView, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        parent.addView(swipeRefreshLayout, webViewIndex);

        swipeRefreshLayout.setOnRefreshListener(() -> webView.reload());

        fetchBlockedUrlsFromGitHub();

        filePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (fileUploadCallback == null) return;
                Uri[] results = null;
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                fileUploadCallback.onReceiveValue(results);
                fileUploadCallback = null;
            }
        );

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new ClipboardBridge(this), "AndroidClipboard");
        webView.addJavascriptInterface(new BlobBridge(), "AndroidBlob");
        webView.addJavascriptInterface(new AndroidDeviceBridge(), "AndroidDevice");

        webView.setWebViewClient(new WebViewClient() {
            private boolean isOfflinePage = false;

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String url = req.getUrl().toString();
                String scheme = req.getUrl().getScheme();

                if ("intent".equals(scheme)) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        if (getPackageManager().resolveActivity(intent, 0) != null) {
                            startActivity(intent);
                        } else {
                            String pkg = intent.getPackage();
                            if (pkg != null) {
                                startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("market://details?id=" + pkg)));
                            }
                        }
                    } catch (Exception e) {
                    }
                    return true;
                }

                if ("tel".equals(scheme) || "mailto".equals(scheme) ||
                    "sms".equals(scheme) || "smsto".equals(scheme) ||
                    "market".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this,
                            "Tidak ada aplikasi untuk membuka link ini", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }

                if (url.contains("wa.me") || url.contains("api.whatsapp.com") ||
                    "whatsapp".equals(scheme)) {
                    try {
                        Intent waIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        waIntent.setPackage("com.whatsapp");
                        if (getPackageManager().resolveActivity(waIntent, 0) != null) {
                            startActivity(waIntent);
                        } else {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        }
                    } catch (Exception e) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    }
                    return true;
                }

                if ("tg".equals(scheme) || url.contains("t.me")) {
                    try {
                        Intent tgIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        tgIntent.setPackage("org.telegram.messenger");
                        if (getPackageManager().resolveActivity(tgIntent, 0) != null) {
                            startActivity(tgIntent);
                        } else {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        }
                    } catch (Exception e) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    }
                    return true;
                }

                if ("http".equals(scheme) || "https".equals(scheme)) {
                    String urlLower = url.toLowerCase();
                    if (urlLower.endsWith(".apk") || urlLower.endsWith(".zip") ||
                        urlLower.endsWith(".pdf") || urlLower.endsWith(".mp4") ||
                        urlLower.endsWith(".mp3") || urlLower.contains("download") && urlLower.contains("apk") ||
                        urlLower.contains("attachment") || urlLower.contains("content-disposition")) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        } catch (Exception e) {
                            view.loadUrl(url);
                        }
                        return true;
                    }
                    view.loadUrl(url);
                    return true;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, android.webkit.WebResourceRequest req,
                    android.webkit.WebResourceError err) {
                super.onReceivedError(view, req, err);
                if (!req.isForMainFrame()) return;
                if (isOfflinePage) return;
                isOfflinePage = true;
                if (swipeRefreshLayout != null) swipeRefreshLayout.setRefreshing(false);
                runOnUiThread(() -> view.loadDataWithBaseURL(
                    null, OFFLINE_HTML, "text/html", "UTF-8", null));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                isOfflinePage = false;
                CookieManager.getInstance().flush();

                view.evaluateJavascript(
                    "(function() {" +
                    "  if (typeof AndroidClipboard === 'undefined') return;" +
                    "  if (!navigator.clipboard || !navigator.clipboard.writeText) {" +
                    "    navigator.clipboard = {" +
                    "      writeText: function(text) {" +
                    "        AndroidClipboard.copy(text);" +
                    "        return Promise.resolve();" +
                    "      }," +
                    "      readText: function() {" +
                    "        return Promise.resolve(AndroidClipboard.paste());" +
                    "      }" +
                    "    };" +
                    "  }" +
                    "})();",
                    null
                );

                if (swipeRefreshLayout != null) swipeRefreshLayout.setRefreshing(false);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    WebChromeClient.FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                    fileUploadCallback = null;
                }
                fileUploadCallback = filePathCallback;
                requestStoragePermissionIfNeeded();
                Intent intent = fileChooserParams.createIntent();
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    filePickerLauncher.launch(intent);
                } catch (Exception e) {
                    fileUploadCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                    String contentDisposition, String mimeType, long contentLength) {
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1002);
                        Toast.makeText(MainActivity.this,
                            "Izinkan akses storage lalu coba download lagi",
                            Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                try {
                    if (url.startsWith("blob:")) {
                        String blobFileName = "download_" + System.currentTimeMillis();
                        if (contentDisposition != null && contentDisposition.contains("filename=")) {
                            try {
                                blobFileName = contentDisposition
                                    .substring(contentDisposition.indexOf("filename=") + 9)
                                    .replaceAll("\"", "").split(";")[0].trim();
                            } catch (Exception ignored) {}
                        } else if (url.contains("/")) {
                            String urlPart = url.substring(url.lastIndexOf('/') + 1).split("\\?")[0];
                            if (!urlPart.isEmpty()) blobFileName = urlPart;
                        }
                        final String safeBlobName = blobFileName.replace("'", "\\'");
                        webView.evaluateJavascript(
                            "(function() {" +
                            "  var xhr = new XMLHttpRequest();" +
                            "  xhr.open('GET', '" + url.replace("'", "\\'") + "', true);" +
                            "  xhr.responseType = 'blob';" +
                            "  xhr.onload = function() {" +
                            "    var reader = new FileReader();" +
                            "    reader.onloadend = function() {" +
                            "      AndroidBlob.onBlobReady(reader.result, '" + safeBlobName + "');" +
                            "    };" +
                            "    reader.readAsDataURL(xhr.response);" +
                            "  };" +
                            "  xhr.send();" +
                            "})()", null);
                        return;
                    }

                    if (url.startsWith("data:")) {
                        String ext = "bin";
                        int semiIdx = url.indexOf(';');
                        int commaIdx = url.indexOf(',');
                        String mime = url.substring(5, semiIdx > 0 ? semiIdx : commaIdx);
                        switch (mime) {
                            case "image/jpeg": case "image/jpg": ext = "jpg"; break;
                            case "image/png":  ext = "png";  break;
                            case "image/gif":  ext = "gif";  break;
                            case "image/webp": ext = "webp"; break;
                            case "image/svg+xml": ext = "svg"; break;
                            case "application/pdf": ext = "pdf"; break;
                            case "application/zip": ext = "zip"; break;
                            case "application/vnd.android.package-archive": ext = "apk"; break;
                            case "text/plain": ext = "txt"; break;
                            case "text/html":  ext = "html"; break;
                            case "application/json": ext = "json"; break;
                            case "audio/mpeg": ext = "mp3"; break;
                            case "audio/ogg":  ext = "ogg"; break;
                            case "video/mp4":  ext = "mp4"; break;
                        }
                        final String fileExt = ext;
                        new Thread(() -> {
                            try {
                                String base64 = url.substring(url.indexOf(",") + 1);
                                byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.NO_WRAP | android.util.Base64.NO_PADDING);
                                String fileName = "download_" + System.currentTimeMillis() + "." + fileExt;
                                java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                                if (!dir.exists()) dir.mkdirs();
                                java.io.File file = new java.io.File(dir, fileName);
                                java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
                                fos.write(bytes);
                                fos.close();
                                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
                                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                                    "Tersimpan: " + fileName, Toast.LENGTH_SHORT).show());
                            } catch (Exception ex) {
                                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                                    "Gagal simpan: " + ex.getMessage(), Toast.LENGTH_LONG).show());
                            }
                        }).start();
                        return;
                    }

                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    if (mimeType != null && !mimeType.isEmpty()) {
                        request.setMimeType(mimeType);
                    }
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) request.addRequestHeader("Cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setDescription("Mendownload file...");

                    String fileName = "download_" + System.currentTimeMillis();
                    if (contentDisposition != null) {
                        if (contentDisposition.contains("filename*=")) {
                            try {
                                String raw = contentDisposition.substring(
                                    contentDisposition.indexOf("filename*=") + 10).trim();
                                if (raw.toUpperCase().startsWith("UTF-8\'\'")) raw = raw.substring(7);
                                fileName = java.net.URLDecoder.decode(raw.split(";")[0].trim(), "UTF-8");
                            } catch (Exception ignored) {}
                        } else if (contentDisposition.contains("filename=")) {
                            fileName = contentDisposition.substring(
                                contentDisposition.indexOf("filename=") + 9
                            ).replaceAll("\"", "").split(";")[0].trim();
                        }
                    }
                    if (fileName.startsWith("download_") && url.contains("/")) {
                        String urlFile = url.substring(url.lastIndexOf('/') + 1).split("\\?")[0];
                        if (!urlFile.isEmpty() && urlFile.contains(".")) {
                            try { fileName = java.net.URLDecoder.decode(urlFile, "UTF-8"); }
                            catch (Exception ignored) { fileName = urlFile; }
                        }
                    }

                    request.setTitle(fileName);
                    request.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    );
                    request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS, fileName
                    );

                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(request);
                        Toast.makeText(MainActivity.this,
                            "Download dimulai: " + fileName,
                            Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                        "Gagal download: " + e.getMessage(),
                        Toast.LENGTH_LONG).show();
                }
            }
        });
        
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        if ("remote".equals(URL_MODE)) {
            String rawTxtUrl = decodeUrl();
            new Thread(() -> {
                try {
                    java.net.URL fetchUrl = new java.net.URL(rawTxtUrl);
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) fetchUrl.openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    conn.setRequestMethod("GET");
                    java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line.trim());
                    br.close();
                    conn.disconnect();
                    String finalUrl = sb.toString().trim();
                    if (finalUrl.startsWith("http://") || finalUrl.startsWith("https://")) {
                        runOnUiThread(() -> webView.loadUrl(finalUrl));
                    } else {
                        runOnUiThread(() -> Toast.makeText(this,
                            "URL di txt tidak valid", Toast.LENGTH_LONG).show());
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> webView.loadDataWithBaseURL(
                        null, OFFLINE_HTML, "text/html", "UTF-8", null));
                }
            }).start();
        } else {
            webView.loadUrl(decodeUrl());
        }
    }

    private void requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1001);
            }
        }
    }
    
    private void fetchBlockedUrlsFromGitHub() {
        new Thread(() -> {
            try {
                URL url = new URL(BLOCKED_URLS_SOURCE);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestMethod("GET");
                
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
                );
                
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                reader.close();
                conn.disconnect();
                
                JSONObject jsonObject = new JSONObject(sb.toString());
                Iterator<String> keys = jsonObject.keys();
                
                while (keys.hasNext()) {
                    String key = keys.next();
                    String urlValue = jsonObject.getString(key);
                    if (urlValue != null && !urlValue.trim().isEmpty()) {
                        blockedUrls.add(urlValue.trim());
                    }
                }
                                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private boolean isCurrentUrlBlocked() {
        try {
            String currentUrl = webView.getUrl();
            if (currentUrl == null) return false;
            
            for (String blocked : blockedUrls) {
                if (blocked.contains("*")) {
                    String pattern = blocked
                        .replace(".", "\\.")
                        .replace("*", ".*");
                    if (currentUrl.matches(".*" + pattern + ".*")) {
                        return true;
                    }
                } else {
                    if (currentUrl.contains(blocked)) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
