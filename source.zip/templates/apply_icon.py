from PIL import Image
sizes = {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}
img = Image.open('icon.png').convert('RGBA')
for dpi, sz in sizes.items():
    resized = img.resize((sz, sz), Image.LANCZOS)
    for name in ['ic_launcher', 'ic_launcher_round']:
        resized.save(f'app/src/main/res/mipmap-{dpi}/{name}.png')
print('Custom icons applied')
