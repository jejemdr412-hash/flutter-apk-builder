import struct, zlib, sys

def make_png(w, h, color):
    raw = b''
    for _ in range(h):
        raw += b'\x00' + bytes(color) * w
    idat = zlib.compress(raw)
    def chunk(tag, data):
        c = struct.pack('>I', len(data)) + tag + data
        c += struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)
        return c
    sig = b'\x89PNG\r\n\x1a\n'
    ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
    idat_chunk = chunk(b'IDAT', idat)
    iend = chunk(b'IEND', b'')
    return sig + ihdr + idat_chunk + iend

sizes = {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}
for dpi, sz in sizes.items():
    data = make_png(sz, sz, [26, 26, 46])
    for name in ['ic_launcher', 'ic_launcher_round']:
        with open(f'app/src/main/res/mipmap-{dpi}/{name}.png', 'wb') as f:
            f.write(data)
print('Icons generated')
