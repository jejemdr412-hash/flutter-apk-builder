const { Telegraf, Markup } = require('telegraf');
const { Octokit } = require('@octokit/rest');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

const config = require('./config');

function resolveTmpBase() {
  const candidates = [
    process.env.TMPDIR,
    process.env.TEMP,
    process.env.TMP,
    '/tmp',
    path.join(process.env.HOME || __dirname, 'tmp'),
    path.join(__dirname, 'tmp'),
  ];
  for (const dir of candidates) {
    if (!dir) continue;
    try {
      fs.mkdirSync(dir, { recursive: true });
      const probe = path.join(dir, `.probe_${process.pid}`);
      fs.writeFileSync(probe, '1');
      fs.unlinkSync(probe);
      return dir;
    } catch (_) {}
  }
  const fallback = path.join(__dirname, 'tmp');
  fs.mkdirSync(fallback, { recursive: true });
  return fallback;
}

const TMP_BASE = resolveTmpBase();
console.log(`\uD83D\uDCC1 Tmp Base Dir: ${TMP_BASE}`);

const STATUS_FILE = path.join(__dirname, 'status.json');

function loadStatus() {
  if (!fs.existsSync(STATUS_FILE)) return { activeAccount: 1 };
  try {
    const data = JSON.parse(fs.readFileSync(STATUS_FILE, 'utf-8'));
    return { activeAccount: data.activeAccount === 2 ? 2 : 1 };
  } catch (_) {
    return { activeAccount: 1 };
  }
}

function saveStatus(activeAccount) {
  fs.writeFileSync(STATUS_FILE, JSON.stringify({
    activeAccount,
    updatedAt: new Date().toISOString(),
  }, null, 2));
}

let activeAccount = loadStatus().activeAccount;
let GH_USERNAME = activeAccount === 2 ? config.GithubUsername2 : config.GithubUsername;
let GH_TOKEN = activeAccount === 2 ? config.GithubToken2 : config.GithubToken;

const bot = new Telegraf(config.BotToken, { handlerTimeout: 86_400_000 });
let octokit = new Octokit({ auth: GH_TOKEN });

const PREM_FILE = path.join(__dirname, 'premium_build.json');
const RESS_FILE = path.join(__dirname, 'reseller_build.json');

function loadPremium() {
  if (!fs.existsSync(PREM_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(PREM_FILE, 'utf-8')); } catch { return []; }
}

function savePremium(list) {
  fs.writeFileSync(PREM_FILE, JSON.stringify(list, null, 2));
}

function loadReseller() {
  if (!fs.existsSync(RESS_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(RESS_FILE, 'utf-8')); } catch { return []; }
}

function saveReseller(list) {
  fs.writeFileSync(RESS_FILE, JSON.stringify(list, null, 2));
}

let premiumUsers = loadPremium();
let resellerUsers = loadReseller();

function isAllowed(userId) {
  return String(userId) === config.OwnerId || premiumUsers.includes(String(userId));
}

function isReseller(userId) {
  return resellerUsers.includes(String(userId));
}

const userStates = {};
const lastErrorLog = {};

function saveErrorLog(chatId, repoName, content) {
  lastErrorLog[chatId] = { repoName, content, time: new Date() };
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const parts = [];
  if (d) parts.push(`${d}Hari`);
  if (h) parts.push(`${h}Jam`);
  if (m) parts.push(`${m}Menit`);
  parts.push(`${s}Detik`);
  return parts.join(' ');
}

const buildQueue = [];
let isProcessing = false;

function getQueuePosition(userId) {
  return buildQueue.findIndex(e => e.userId === String(userId));
}

function getQueueEntry(userId) {
  return buildQueue.find(e => e.userId === String(userId));
}

async function processQueue() {
  if (isProcessing) return;
  if (buildQueue.length === 0) return;

  const entry = buildQueue[0];

  if (!entry.fileId) return;

  isProcessing = true;
  const state = userStates[entry.userId];
  if (state) state.step = 'processing';

  if (entry.notifyWhenStarted) {
    bot.telegram.sendMessage(entry.chatId,
`✅ <b>Giliran Kamu Tiba!</b>

🔨 Build Antrian Sebelum Kamu Sudah Selesai.
🚀 ZIP Kamu Sekarang Sedang Diupload & Dibuild Ke GitHub...
📂 <b>Nama Folder:</b> <code>${entry.repoName}</code>`,
      { parse_mode: 'HTML' }
    ).catch(() => {});
  }

  try {
    await runBuild(entry.chatId, Number(entry.userId), state || { repoName: entry.repoName }, entry.fileId, entry.fileName, entry.username);
  } catch (err) {
    console.error(`❌ [QUEUE RUNBUILD CRASH] User: ${entry.userId}`, err.message);
  }

  if (isProcessing && buildQueue[0] === entry) {
    releaseLockAndNotify(entry.userId);
  }
}

function loadingBar(percent) {
  const total = 12;
  const filled = Math.round((percent / 100) * total);
  const bar = '▰'.repeat(filled) + '▱'.repeat(total - filled);
  return `${bar} <code>${percent}%</code>`;
}

async function editMsg(chatId, msgId, text) {
  try {
    await bot.telegram.editMessageText(chatId, msgId, null, text, { parse_mode: 'HTML' });
  } catch (_) {}
}

function collectFiles(extractDir) {
  const allFiles = [];

  function walk(currentDir, currentBase) {
    const items = fs.readdirSync(currentDir);
    for (const item of items) {
      const fullPath = path.join(currentDir, item);
      const relPath = currentBase ? `${currentBase}/${item}` : item;
      if (fs.statSync(fullPath).isDirectory()) {
        walk(fullPath, relPath);
      } else {
        allFiles.push({ fullPath, relPath });
      }
    }
  }

  walk(extractDir, '');

  const topLevel = new Set(allFiles.map(f => f.relPath.split('/')[0]));
  let stripPrefix = '';
  if (topLevel.size === 1) {
    const candidate = [...topLevel][0];
    const candidatePath = path.join(extractDir, candidate);
    if (fs.existsSync(candidatePath) && fs.statSync(candidatePath).isDirectory()) {
      stripPrefix = candidate + '/';
    }
  }

  const normal = [];
  const workflow = [];

  for (const file of allFiles) {
    const uploadPath = stripPrefix ? file.relPath.slice(stripPrefix.length) : file.relPath;
    if (!uploadPath) continue;
    const content = fs.readFileSync(file.fullPath).toString('base64');
    const fileObj = { path: uploadPath, content };
    const lowerPath = uploadPath.toLowerCase();
    if (lowerPath.startsWith('.github/workflows/') && (lowerPath.endsWith('.yml') || lowerPath.endsWith('.yaml'))) {
      workflow.push(fileObj);
    } else {
      normal.push(fileObj);
    }
  }

  return { normal, workflow };
}

async function uploadToGitHub(owner, repo, filePath, content, message) {
  let sha;
  try {
    const existing = await octokit.repos.getContent({ owner, repo, path: filePath });
    sha = existing.data.sha;
  } catch (_) {}

  await octokit.repos.createOrUpdateFileContents({
    owner,
    repo,
    path: filePath,
    message,
    content,
    ...(sha ? { sha } : {}),
  });
}

async function pollBuild(owner, repo, maxMinutes = 15) {
  const maxAttempts = (maxMinutes * 60) / 12;
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(r => setTimeout(r, 12000));
    try {
      const { data } = await octokit.actions.listWorkflowRunsForRepo({ owner, repo, per_page: 1 });
      if (!data.workflow_runs.length) continue;
      const run = data.workflow_runs[0];
      if (run.status === 'completed') {
        return { success: run.conclusion === 'success', runId: run.id, conclusion: run.conclusion };
      }
    } catch (_) {}
  }
  return { success: false, runId: null, conclusion: 'timeout' };
}

async function getArtifactUrl(owner, repo, runId) {
  const { data } = await octokit.actions.listWorkflowRunArtifacts({ owner, repo, run_id: runId });
  if (!data.artifacts.length) return null;
  return data.artifacts[0].archive_download_url;
}

function cleanup(dir) {
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}
}

async function deleteRepo(repoName) {
  try {
    await octokit.repos.delete({ owner: GH_USERNAME, repo: repoName });
  } catch (_) {}
}

async function deleteRepoDelayed(chatId, repoName, delayMinutes = 2) {
  const delayMs = delayMinutes * 60 * 1000;
  const notifMsg = await bot.telegram.sendMessage(chatId,
`🗑 <b>Folder Akan Dihapus Otomatis</b>

📂 <b>Nama Folder:</b> <code>${repoName}</code>
⏳ Folder Akan Dihapus Dalam <b>${delayMinutes} Menit</b>...`,
    { parse_mode: 'HTML' }
  );

  await new Promise(r => setTimeout(r, delayMs));

  await deleteRepo(repoName);
  await editMsg(chatId, notifMsg.message_id,
`✅ <b>Folder Berhasil Dihapus</b>

📂 <b>Nama Folder:</b> <code>${repoName}</code>
🗑 Folder Sudah Dihapus Dari GitHub.`
  );
}

async function getBuildLogs(owner, repo, runId) {
  try {
    const { data: jobsData } = await octokit.actions.listJobsForWorkflowRun({
      owner, repo, run_id: runId
    });

    if (!jobsData.jobs.length) return null;

    const failedJob = jobsData.jobs.find(j => j.conclusion === 'failure') || jobsData.jobs[0];
    const jobId = failedJob.id;

    const logsResp = await octokit.actions.downloadJobLogsForWorkflowRun({
      owner, repo, job_id: jobId
    });

    const logText = await axios.get(logsResp.url, { responseType: 'text' });
    const fullText = logText.data;
    const lines = fullText.split('\n');

    const errorLines = lines.filter(l =>
      /error|failed|exception|fatal|gradle|what went wrong/i.test(l)
    ).slice(-30);

    const lastLines = lines.slice(-40);

    const combined = [...new Set([...errorLines, ...lastLines])].join('\n');
    return { preview: combined.slice(0, 3500), full: fullText };
  } catch (err) {
    return null;
  }
}

function releaseLockAndNotify(userId) {
  isProcessing = false;
  const idx = buildQueue.findIndex(e => e.userId === String(userId));
  if (idx !== -1) buildQueue.splice(idx, 1);

  if (buildQueue.length > 0) {
    buildQueue[0].notifyWhenStarted = true;
  }

  processQueue().catch((err) => console.error('❌ [PROCESS QUEUE ERROR]', err.message));
}

async function runBuild(chatId, userId, state, fileId, fileName, username = 'unknown') {
  const userIdStr = String(userId);
  const tmpDir = path.join(TMP_BASE, `pegasus_${userId}_${Date.now()}`);
  fs.mkdirSync(tmpDir, { recursive: true });

  console.log(`\n🚀 [BUILD STARTED]`);
  console.log(`   👤 Username  : @${username} (${userId})`);
  console.log(`   📄 File Name : ${fileName}`);
  console.log(`   📂 Folder   : ${state.repoName}`);
  console.log(`   📁 Tmp Dir  : ${tmpDir}`);
  console.log(`   🕐 Time     : ${new Date().toLocaleString()}`);

  const statusMsg = await bot.telegram.sendMessage(chatId,
    `📥 <b>Mengunduh File ZIP...</b>\n\n${loadingBar(5)}`,
    { parse_mode: 'HTML' }
  );
  const msgId = statusMsg.message_id;

  try {
    console.log(`   📡 Mengambil Link File Dari Telegram...`);
    const fileLink = await bot.telegram.getFileLink(fileId);
    console.log(`   🔗 File URL  : ${fileLink.href}`);
    const zipPath = path.join(tmpDir, 'project.zip');

    const dlResponse = await axios.get(fileLink.href, {
      responseType: 'arraybuffer',
      maxRedirects: 10,
      timeout: 120000,
      headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': '*/*' },
    });
    const writtenSize = Buffer.from(dlResponse.data).length;
    fs.writeFileSync(zipPath, Buffer.from(dlResponse.data));
    console.log(`   ✅ Download Selesai: ${(writtenSize / 1024 / 1024).toFixed(2)} MB`);

    await editMsg(chatId, msgId, `📂 <b>Mengekstrak File ZIP...</b>\n\n${loadingBar(15)}`);

    const extractDir = path.join(tmpDir, 'extracted');
    fs.mkdirSync(extractDir, { recursive: true });

    const zip = new AdmZip(zipPath);
    zip.extractAllTo(extractDir, true);
    console.log(`   ✅ Ekstrak Selesai Ke: ${extractDir}`);

    await editMsg(chatId, msgId, `🔍 <b>Memindai File Proyek...</b>\n\n${loadingBar(25)}`);

    const { normal, workflow } = collectFiles(extractDir);
    const totalFiles = normal.length + workflow.length;
    console.log(`   📊 File Ditemukan: ${totalFiles} Total (${normal.length} Normal, ${workflow.length} Workflow)`);

    if (totalFiles === 0) {
      await editMsg(chatId, msgId,
`❌ <b>ZIP Kosong!</b>

😔 Tidak Ada File Di Dalam ZIP.

🔁 Antrian Kamu Di-Skip. Ketik <code>/buildapp</code> Lagi Untuk Build Ulang.`
      );
      cleanup(tmpDir);
      releaseLockAndNotify(userId);
      delete userStates[userId];
      deleteRepoDelayed(chatId, state.repoName, 5).catch(() => {});
      return;
    }

    if (workflow.length === 0) {
      await editMsg(chatId, msgId,
`❌ <b>ZIP Tidak Valid!</b>

⚠️ File <code>build.yml</code> Tidak Ditemukan Di Dalam ZIP.

📋 Pastikan ZIP Kamu Mengandung File <code>.github/workflows/build.yml</code>.
🔁 Antrian Kamu Di-Skip. Ketik <code>/buildapp</code> Lagi Untuk Build Ulang.`
      );
      cleanup(tmpDir);
      releaseLockAndNotify(userId);
      delete userStates[userId];
      deleteRepoDelayed(chatId, state.repoName, 5).catch(() => {});
      return;
    }

    await editMsg(chatId, msgId,
`⬆️ <b>Mengunggah File Proyek...</b>

${loadingBar(30)}

📄 <code>0/${totalFiles}</code> File Terunggah`
    );

    const repoName = state.repoName;
    let uploaded = 0;

    for (const file of normal) {
      await uploadToGitHub(GH_USERNAME, repoName, file.path, file.content, `Add ${file.path}`);
      uploaded++;
      if (uploaded % Math.max(1, Math.floor(normal.length / 5)) === 0 || uploaded === normal.length) {
        const pct = 30 + Math.round((uploaded / totalFiles) * 35);
        await editMsg(chatId, msgId,
`⬆️ <b>Mengunggah File Proyek...</b>

${loadingBar(pct)}

📄 <code>${uploaded}/${totalFiles}</code> File Terunggah`
        );
      }
    }

    for (const file of workflow) {
      await uploadToGitHub(GH_USERNAME, repoName, file.path, file.content, `Add workflow ${file.path}`);
      uploaded++;
    }

    await editMsg(chatId, msgId,
`✅ <b>Semua File Berhasil Diunggah!</b>

${loadingBar(70)}

📄 <code>${totalFiles}/${totalFiles}</code> File Terunggah`
    );

    await editMsg(chatId, msgId,
`🔨 <b>Sedang Membuat Aplikasi...</b>

${loadingBar(72)}

⏳ Menunggu Proses Build Dimulai...`
    );

    await new Promise(r => setTimeout(r, 8000));

    let elapsed = 0;

    const updateInterval = setInterval(async () => {
      elapsed += 12;
      const pct = Math.min(90, 72 + Math.floor(elapsed / 12));
      await editMsg(chatId, msgId,
`🔨 <b>Sedang Membuat Aplikasi...</b>

${loadingBar(pct)}

⏳ Build Berjalan... <code>${elapsed}s</code>`
      );
    }, 12000);

    const buildResult = await pollBuild(GH_USERNAME, repoName, 15);
    clearInterval(updateInterval);
    console.log(`   🏁 Build result: ${buildResult.conclusion} (runId: ${buildResult.runId})`);

    if (!buildResult.success) {
      const reason = buildResult.conclusion === 'timeout'
        ? '⏰ Build Melebihi Batas Waktu 15 Menit.'
        : `💀 Build Selesai Dengan Status: <code>${buildResult.conclusion}</code>`;
      await editMsg(chatId, msgId,
`❌ <b>Build Gagal!</b>

${reason}

🔍 Sedang Mengambil Log Error...`
      );

      if (buildResult.runId) {
        const logs = await getBuildLogs(GH_USERNAME, repoName, buildResult.runId);
        if (logs) {
          saveErrorLog(chatId, repoName, logs.full);
          await bot.telegram.sendMessage(chatId,
`📋 <b>Log Error Build:</b>

<blockquote><code>${logs.preview.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</code></blockquote>

💡 Gunakan <code>/log</code> untuk minta log lengkap jika perlu.`,
            { parse_mode: 'HTML' }
          );
        } else {
          await bot.telegram.sendMessage(chatId,
`⚠️ <b>Log Tidak Tersedia</b>

😔 Tidak Bisa Mengambil Log Error Dari GitHub Actions.`,
            { parse_mode: 'HTML' }
          );
        }
      }

      cleanup(tmpDir);
      releaseLockAndNotify(userId);
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    await editMsg(chatId, msgId,
`📦 <b>Build Selesai! Mengunduh APK...</b>

${loadingBar(92)}`
    );

    const artifactUrl = await getArtifactUrl(GH_USERNAME, repoName, buildResult.runId);
    if (!artifactUrl) {
      await editMsg(chatId, msgId,
`❌ <b>Artifact Tidak Ditemukan!</b>

😔 Build Selesai Tapi Tidak Ada File Yang Dihasilkan.`
      );
      cleanup(tmpDir);
      releaseLockAndNotify(userId);
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    const artifactResp = await axios.get(artifactUrl, {
      headers: { Authorization: `token ${GH_TOKEN}`, Accept: 'application/vnd.github.v3+json' },
      responseType: 'arraybuffer',
      maxRedirects: 10,
    });

    await editMsg(chatId, msgId,
`📱 <b>Mengekstrak APK...</b>

${loadingBar(96)}`
    );

    const artifactZipPath = path.join(tmpDir, 'artifact.zip');
    fs.writeFileSync(artifactZipPath, artifactResp.data);

    const artifactZip = new AdmZip(artifactZipPath);
    const entries = artifactZip.getEntries();
    const apkEntry = entries.find(e => e.entryName.toLowerCase().endsWith('.apk'));

    if (!apkEntry) {
      await editMsg(chatId, msgId,
`❌ <b>APK Tidak Ditemukan!</b>

😔 Tidak Ada File <code>.apk</code> Di Dalam Hasil Build.`
      );
      cleanup(tmpDir);
      releaseLockAndNotify(userId);
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    const apkName = path.basename(apkEntry.entryName);
    const apkPath = path.join(tmpDir, apkName);
    fs.writeFileSync(apkPath, apkEntry.getData());

    await editMsg(chatId, msgId,
`✅ <b>Build Berhasil!</b>

${loadingBar(100)}

📱 Mengirim APK Ke Chat...`
    );

    const apkSizeBytes = fs.statSync(apkPath).size;
    const MAX_TG_SIZE = 50 * 1024 * 1024;

    if (apkSizeBytes > MAX_TG_SIZE) {
      await editMsg(chatId, msgId,
`✅ <b>Build Berhasil!</b>

${loadingBar(100)}

📦 APK Terlalu Besar Untuk Telegram, Mengunggah Ke Server...`
      );

      const tagName = `release-${Date.now()}`;
      const releaseResp = await octokit.repos.createRelease({
        owner: GH_USERNAME,
        repo: repoName,
        tag_name: tagName,
        name: apkName,
        body: 'APK Hasil Build Otomatis Oleh Pegasus-X Builder Bot',
        draft: false,
        prerelease: false,
      });

      const uploadUrl = releaseResp.data.upload_url;
      const apkBuffer = fs.readFileSync(apkPath);

      await octokit.repos.uploadReleaseAsset({
        url: uploadUrl,
        headers: {
          'content-type': 'application/vnd.android.package-archive',
          'content-length': apkBuffer.length,
        },
        name: apkName,
        data: apkBuffer,
      });

      const downloadUrl = `https://github.com/${GH_USERNAME}/${repoName}/releases/download/${tagName}/${apkName}`;
      const apkSizeMB = (apkSizeBytes / (1024 * 1024)).toFixed(1);

      await bot.telegram.sendMessage(chatId,
`🎉 <b>Aplikasi Berhasil Dibuat!</b>

📱 <b>Nama File:</b> <code>${apkName}</code>
📂 <b>Nama Folder:</b> <code>${repoName}</code>
📦 <b>Ukuran:</b> <code>${apkSizeMB} MB</code>

⚠️ <i>APK Terlalu Besar Untuk Dikirim Langsung, Gunakan Link Di Bawah:</i>

🔗 <b>Link Download:</b>
<code>${downloadUrl}</code>

🦅 <i>Dibuat Oleh Pegasus-X Builder Bot</i>`,
        { parse_mode: 'HTML' }
      );
    } else {
      await bot.telegram.sendDocument(chatId,
        { source: apkPath, filename: apkName },
        {
          caption:
`🎉 <b>Aplikasi Berhasil Dibuat!</b>

📱 <b>Nama File:</b> <code>${apkName}</code>
📂 <b>Nama Folder:</b> <code>${repoName}</code>

🦅 <i>Dibuat Oleh Pegasus-X Builder Bot</i>`,
          parse_mode: 'HTML',
        }
      );
    }

    cleanup(tmpDir);
    releaseLockAndNotify(userId);
    delete userStates[userId];
    deleteRepoDelayed(chatId, repoName, 2).catch(() => {});

  } catch (err) {
    console.error(`\n❌ [BUILD ERROR] @${username} (${userId})`);
    console.error(`   Folder : ${state.repoName}`);
    console.error(`   Error  : ${err.message}`);
    console.error(err.stack);
    saveErrorLog(chatId, state.repoName, `${err.message}\n\n${err.stack || ''}`);
    await editMsg(chatId, msgId,
`❌ <b>Terjadi Kesalahan!</b>

🔴 <b>Error:</b>
<blockquote><code>${err.message}</code></blockquote>

💡 Gunakan <code>/log</code> untuk minta log lengkap jika perlu.`
    );
    cleanup(tmpDir);
    releaseLockAndNotify(userId);
    delete userStates[userId];
    deleteRepoDelayed(chatId, state.repoName, 5).catch(() => {});
  }
}

let BOT_START_TIME = Math.floor(Date.now() / 1000);

bot.use((ctx, next) => {
  const msgDate = ctx.message?.date || ctx.channelPost?.date || ctx.editedMessage?.date;
  if (msgDate && msgDate < BOT_START_TIME) {
    return;
  }
  return next();
});

const START_BANNER_URL  = 'https://files.catbox.moe/qn1xs5.jpg';
const BUY_ICON_EMOJI_ID = '5465281219132415627';
const START_STYLE_CYCLE = ['primary', 'success', 'danger'];
const startActiveCyclers = new Map();

function buildBotKeyboard(styleIndex) {
  const style = START_STYLE_CYCLE[styleIndex % START_STYLE_CYCLE.length];
  return {
    inline_keyboard: [
      [
        {
          text: 'BUY ACCESS',
          url: 'https://t.me/ZalRyuichi',
          style,
          icon_custom_emoji_id: BUY_ICON_EMOJI_ID,
        },
      ],
    ],
  };
}

function buildBotStartHtml(uptime, status_usn) {
  return `
<img src="${START_BANNER_URL}"/>

<h1>RYUICHI BUILDER</h1>
<p>
  Selamat Datang Di <b>Ryuichi Builder</b>. Bot Multifungsi Yang Dirancang Untuk
  Membuat Aplikasi Android Dan Membuat Aplikasi Dari Sebuah Website. Dibangun Dengan <mark>JavaScript</mark>
  Menggunakan Framework <b>Telegraf</b>.
</p>

<hr/>

<table bordered striped>
  <caption>ʚ¡ɞ ִֶָ˖ ࣪𓂃 Info Bot 𓂃 ࣪˖ ִֶָʚ¡ɞ</caption>
  <tr>
    <th>Field</th>
    <th>Value</th>
  </tr>
  <tr>
    <td><b>Creator</b></td>
    <td>@ZalRyuichi</td>
  </tr>
  <tr>
    <td><b>Framework</b></td>
    <td>Telegraf <sup>V9</sup></td>
  </tr>
  <tr>
    <td><b>Language</b></td>
    <td>JavaScript <sup>ES2026</sup></td>
  </tr>
  <tr>
    <td><b>Uptime</b></td>
    <td>${uptime} <mark>LIVE</mark></td>
  </tr>
  <tr>
    <td><b>Access</b></td>
    <td>${status_usn}</td>
  </tr>
  <tr>
    <td><b>Since</b></td>
    <td>2026</td>
  </tr>
</table>

<hr/>

<aside>
  Bot Ini Hanya Bisa Digunakan Oleh Pengguna Yang Memiliki Akses Premium.
  Hubungi Creator Untuk Membeli Akses.
  <cite>Ryuichi Build</cite>
</aside>

<hr/>

<table bordered striped>
  <caption>⌾ ִֶָ˖ ࣪𓂃 Build Command 𓂃 ࣪˖ ִֶָ⌾</caption>
  <tr>
    <th>Command</th>
    <th>Deskripsi</th>
  </tr>
  <tr>
    <td>/buildapp</td>
    <td>Build Aplikasi Android Dari Repository</td>
  </tr>
  <tr>
    <td>/webtoapp</td>
    <td>Konversi Website Ke Aplikasi Android</td>
  </tr>
  <tr>
    <td>/listrepo</td>
    <td>Lihat Daftar Repository Yang Tersimpan</td>
  </tr>
  <tr>
    <td>/delrepo</td>
    <td>Hapus Repository Dari Daftar</td>
  </tr>
  <tr>
    <td>/log</td>
    <td>Lihat Log Build Terakhir</td>
  </tr>
</table>

<table bordered striped>
  <caption>⌾ ִֶָ˖ ࣪𓂃 Owner Command 𓂃 ࣪˖ ִֶָ⌾</caption>
  <tr>
    <th>Command</th>
    <th>Deskripsi</th>
  </tr>
  <tr>
    <td>/address</td>
    <td>Jadikan User Sebagai Reseller</td>
  </tr>
  <tr>
    <td>/delress</td>
    <td>Hapus Reseller</td>
  </tr>
  <tr>
    <td>/addprem</td>
    <td>Tambah User Premium (Owner &amp; Reseller)</td>
  </tr>
  <tr>
    <td>/delprem</td>
    <td>Hapus User Premium</td>
  </tr>
  <tr>
    <td>/listprem</td>
    <td>Lihat Daftar Semua User Premium</td>
  </tr>
  <tr>
    <td>/bc</td>
    <td>Broadcast Pesan Ke Semua User Premium</td>
  </tr>
</table>

<table bordered striped>
  <caption>⌾ ִֶָ˖ ࣪𓂃 Tools Command 𓂃 ࣪˖ ִֶָ⌾</caption>
  <tr>
    <th>Command</th>
    <th>Deskripsi</th>
  </tr>
  <tr>
    <td>/swapacc</td>
    <td>Ganti Akun Aktif</td>
  </tr>
</table>

<hr/>

<a name="footer-section"></a>

<footer>
  <i>#ZalRyuichi #Since2026</i>
</footer>
`.trim();
}

async function sendBotRichMessage(token, chatId, html, keyboard) {
  const res = await axios.post(
    `https://api.telegram.org/bot${token}/sendRichMessage`,
    {
      chat_id: chatId,
      rich_message: { html },
      reply_markup: keyboard,
    }
  );
  if (!res.data.ok) {
    throw new Error(`sendRichMessage gagal: ${JSON.stringify(res.data)}`);
  }
  return res.data.result;
}

function startBotColorCycle(token, chatId, messageId) {
  const key = `${token}:${chatId}`;
  const existing = startActiveCyclers.get(key);
  if (existing) clearInterval(existing);

  let styleIndex = 0;
  const intervalId = setInterval(async () => {
    styleIndex += 1;
    try {
      await axios.post(
        `https://api.telegram.org/bot${token}/editMessageReplyMarkup`,
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: buildBotKeyboard(styleIndex),
        }
      );
    } catch {
      clearInterval(intervalId);
      startActiveCyclers.delete(key);
    }
  }, 5000);

  startActiveCyclers.set(key, intervalId);
}

bot.start(async (ctx) => {
  const uptime     = formatUptime(Math.floor(Date.now() / 1000) - BOT_START_TIME);
  const userIdStr  = String(ctx.from.id);
  const status_usn = userIdStr === config.OwnerId
    ? 'Owner'
    : premiumUsers.includes(userIdStr)
      ? 'Premium'
      : 'Free';

  const token    = ctx.telegram.token;
  const chatId   = ctx.chat.id;
  const html     = buildBotStartHtml(uptime, status_usn);
  const keyboard = buildBotKeyboard(0);

  const sentMessage = await sendBotRichMessage(token, chatId, html, keyboard);
  startBotColorCycle(token, chatId, sentMessage.message_id);
});

bot.command('swapacc', async (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

😔 Command Ini Khusus <b>Owner</b>.`
    );
  }

  const args = ctx.message.text.trim().split(/\s+/);
  const target = Number(args[1]);

  if (!target || (target !== 1 && target !== 2)) {
    return ctx.replyWithHTML(
`📝 <b>Cara Pakai:</b>
<code>/swapacc 1</code> › Ganti Ke Akun GitHub 1
<code>/swapacc 2</code> › Ganti Ke Akun GitHub 2`
    );
  }

  const targetUsername = target === 2 ? config.GithubUsername2 : config.GithubUsername;
  const targetToken = target === 2 ? config.GithubToken2 : config.GithubToken;

  if (!targetUsername || !targetToken) {
    return ctx.replyWithHTML(
`❌ <b>Akun ${target} Belum Dikonfigurasi!</b>

😔 Isi Dulu <code>GithubUsername${target === 2 ? '2' : ''}</code> Dan <code>GithubToken${target === 2 ? '2' : ''}</code> Di <code>config.js</code>.`
    );
  }

  if (activeAccount === target) {
    return ctx.replyWithHTML(
`ℹ️ <b>Sudah Di Akun ${target}</b>

👤 <b>Username:</b> <code>${targetUsername}</code>`
    );
  }

  activeAccount = target;
  GH_USERNAME = targetUsername;
  GH_TOKEN = targetToken;
  octokit = new Octokit({ auth: GH_TOKEN });
  saveStatus(activeAccount);

  await ctx.replyWithHTML(
`✅ <b>Berhasil Ganti Akun!</b>

🔄 <b>Akun Aktif:</b> <code>${activeAccount}</code>
👤 <b>Username:</b> <code>${GH_USERNAME}</code>`
  );
});

bot.command('log', async (ctx) => {
  const chatId = ctx.chat.id;
  const entry = lastErrorLog[chatId];

  if (!entry) {
    return ctx.replyWithHTML(
`⚠️ <b>Tidak Ada Log</b>

😔 Belum Ada Error Build Yang Tercatat Di Chat Ini.`
    );
  }

  const logPath = path.join(TMP_BASE, `errorlog_${chatId}_${Date.now()}.txt`);
  const header =
`PEGASUS-X ERROR LOG
Repo   : ${entry.repoName || '-'}
Waktu  : ${entry.time.toLocaleString()}
${'='.repeat(50)}

`;

  fs.writeFileSync(logPath, header + entry.content);

  await ctx.replyWithDocument(
    { source: fs.createReadStream(logPath), filename: `error_log_${Date.now()}.txt` },
    {
      caption:
`📋 <b>Log Error Lengkap</b>

📂 <b>Repo:</b> <code>${entry.repoName || '-'}</code>
🕐 <b>Waktu:</b> <code>${entry.time.toLocaleString()}</code>`,
      parse_mode: 'HTML',
    }
  );

  try { fs.unlinkSync(logPath); } catch (_) {}
});

bot.command('address', async (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner.`
    );
  }
  const args = ctx.message.text.split(/\s+/);
  if (args.length < 2) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📝 Gunakan: <code>/address [user_id]</code>
💡 User yang di-address bisa pakai <code>/addprem</code>.`
    );
  }
  const targetId = args[1].trim();

  if (targetId === config.OwnerId) {
    return ctx.replyWithHTML(
`ℹ️ <b>Owner Sudah Punya Akses Penuh!</b>

👑 ID Owner Tidak Perlu Di-Address.`
    );
  }

  if (resellerUsers.includes(targetId)) {
    return ctx.replyWithHTML(
`ℹ️ <b>ID Sudah Terdaftar Sebagai Reseller!</b>

👤 <code>${targetId}</code> Sudah Bisa Pakai <code>/addprem</code>.`
    );
  }

  resellerUsers.push(targetId);
  saveReseller(resellerUsers);

  await ctx.replyWithHTML(
`✅ <b>Berhasil Di-Address!</b>

👤 ID: <code>${targetId}</code>
🔑 User Ini Sekarang Bisa Menggunakan <code>/addprem</code>.
🚫 <code>/delprem</code> Tetap Tidak Bisa Digunakan.`
  );

  await ctx.replyWithDocument(
    { source: RESS_FILE, filename: 'reseller_build.json' },
    { caption: `📦 <b>Data Reseller Terbaru</b>\n\n👥 Total: <b>${resellerUsers.length}</b> Reseller`, parse_mode: 'HTML' }
  );
});

bot.command('delress', async (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner.`
    );
  }
  const args = ctx.message.text.split(/\s+/);
  if (args.length < 2) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📝 Gunakan: <code>/delress [user_id]</code>`
    );
  }
  const targetId = args[1].trim();
  if (!resellerUsers.includes(targetId)) {
    return ctx.replyWithHTML(
`ℹ️ <b>ID Tidak Ditemukan!</b>

👤 <code>${targetId}</code> Bukan Reseller.`
    );
  }
  resellerUsers = resellerUsers.filter(id => id !== targetId);
  saveReseller(resellerUsers);
  await ctx.replyWithHTML(
`🗑 <b>Berhasil Dihapus!</b>

👤 <code>${targetId}</code> Sudah Dihapus Dari Daftar Reseller.`
  );
  await ctx.replyWithDocument(
    { source: RESS_FILE, filename: 'reseller_build.json' },
    { caption: `📦 <b>Data Reseller Terbaru</b>\n\n👥 Total: <b>${resellerUsers.length}</b> Reseller`, parse_mode: 'HTML' }
  );
});

bot.command('addprem', async (ctx) => {
  const callerId = String(ctx.from.id);
  const isOwner = callerId === config.OwnerId;
  const isRess = isReseller(callerId);

  if (!isOwner && !isRess) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner Atau Reseller.`
    );
  }
  const args = ctx.message.text.split(/\s+/);
  if (args.length < 2) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📝 Gunakan: <code>/addprem [user_id]</code>`
    );
  }
  const newId = args[1].trim();
  if (premiumUsers.includes(newId)) {
    return ctx.replyWithHTML(
`ℹ️ <b>ID Sudah Terdaftar!</b>

👤 <code>${newId}</code> Sudah Menjadi Pengguna Premium.`
    );
  }
  premiumUsers.push(newId);
  savePremium(premiumUsers);

  const callerName = ctx.from.username ? `@${ctx.from.username}` : `ID: ${callerId}`;

  await ctx.replyWithHTML(
`✅ <b>Berhasil Ditambahkan!</b>

👤 <code>${newId}</code> Sekarang Menjadi Pengguna Premium. 🎉`
  );
  await ctx.replyWithDocument(
    { source: PREM_FILE, filename: 'premium_build.json' },
    { caption: `📦 <b>Backup Data Premium Terbaru</b>\n\n👥 Total: <b>${premiumUsers.length}</b> Pengguna`, parse_mode: 'HTML' }
  );

  // Notif ke owner jika yang addprem adalah reseller
  if (isRess) {
    try {
      await bot.telegram.sendMessage(config.OwnerId,
`🔔 <b>New Premium!</b>

👤 <b>ID Premium:</b> <code>${newId}</code>
🏪 <b>Dibuat Oleh:</b> ${callerName} (<code>${callerId}</code>)`,
        { parse_mode: 'HTML' }
      );
      await bot.telegram.sendDocument(config.OwnerId,
        { source: PREM_FILE, filename: 'premium_build.json' },
        { caption: `📦 <b>premium_build.json Terbaru</b>\n\n👥 Total: <b>${premiumUsers.length}</b> Pengguna`, parse_mode: 'HTML' }
      );
    } catch (err) {
      console.error('⚠️ Gagal Kirim Notif Addprem Ke Owner:', err.message);
    }
  }
});

bot.command('delprem', (ctx) => {
  const callerId = String(ctx.from.id);
  if (callerId !== config.OwnerId) {
    const msg = isReseller(callerId)
      ? `🚫 <b>Akses Ditolak!</b>\n\n❌ Reseller Hanya Bisa Pakai <code>/addprem</code>.\n🚫 <code>/delprem</code> Khusus Owner.`
      : `🚫 <b>Akses Ditolak!</b>\n\n❌ Perintah Ini Hanya Untuk Owner.`;
    return ctx.replyWithHTML(msg);
  }
  const args = ctx.message.text.split(/\s+/);
  if (args.length < 2) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📝 Gunakan: <code>/delprem [user_id]</code>`
    );
  }
  const removeId = args[1].trim();
  if (!premiumUsers.includes(removeId)) {
    return ctx.replyWithHTML(
`ℹ️ <b>ID Tidak Ditemukan!</b>

👤 <code>${removeId}</code> Bukan Pengguna Premium.`
    );
  }
  premiumUsers = premiumUsers.filter(id => id !== removeId);
  savePremium(premiumUsers);
  ctx.replyWithHTML(
`🗑 <b>Berhasil Dihapus!</b>

👤 <code>${removeId}</code> Sudah Dihapus Dari Daftar Premium.`
  );
});

bot.command('listprem', (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner.`
    );
  }
  if (!premiumUsers.length) {
    return ctx.replyWithHTML(
`📋 <b>Daftar Premium Kosong!</b>

😔 Belum Ada Pengguna Premium Yang Terdaftar.`
    );
  }
  const list = premiumUsers.map((id, i) => `${i + 1}. <code>${id}</code>`).join('\n');
  ctx.replyWithHTML(
`👑 <b>Daftar Pengguna Premium:</b>

${list}`
  );
});

bot.command('listrepo', async (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner.`
    );
  }
  const loadMsg = await ctx.replyWithHTML(`📋 <b>Mengambil Daftar Folder...</b>`);
  try {
    const { data } = await octokit.repos.listForAuthenticatedUser({ per_page: 100, sort: 'created', direction: 'desc' });
    if (!data.length) {
      return editMsg(ctx.chat.id, loadMsg.message_id,
`📋 <b>Daftar Folder Kosong!</b>

😔 Belum Ada Folder Yang Dibuat.`
      );
    }
    const list = data.map((r, i) => `${i + 1}. <code>${r.name}</code>`).join('\n');
    await editMsg(ctx.chat.id, loadMsg.message_id,
`📂 <b>Daftar Folder Proyek (${data.length}):</b>

${list}`
    );
  } catch (err) {
    await editMsg(ctx.chat.id, loadMsg.message_id,
`❌ <b>Gagal Mengambil Daftar!</b>

🔴 Error: <code>${err.message}</code>`
    );
  }
});

bot.command('delrepo', async (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner.`
    );
  }
  const args = ctx.message.text.split(/\s+/);
  if (args.length < 2) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📝 Gunakan: <code>/delrepo [nama_folder]</code>`
    );
  }
  const repoName = args[1].trim();
  const confirmMsg = await ctx.replyWithHTML(
`🗑 <b>Menghapus Folder...</b>

📂 <b>Nama Folder:</b> <code>${repoName}</code>`
  );
  try {
    await octokit.repos.delete({ owner: GH_USERNAME, repo: repoName });
    await editMsg(ctx.chat.id, confirmMsg.message_id,
`✅ <b>Folder Berhasil Dihapus!</b>

📂 <b>Nama Folder:</b> <code>${repoName}</code>`
    );
  } catch (err) {
    const msg = err.status === 404
      ? `😔 Folder <code>${repoName}</code> Tidak Ditemukan.`
      : `🔴 Error: <code>${err.message}</code>`;
    await editMsg(ctx.chat.id, confirmMsg.message_id,
`❌ <b>Gagal Menghapus Folder!</b>

${msg}`
    );
  }
});

bot.command('buildapp', async (ctx) => {
  const userId = ctx.from.id;
  const userIdStr = String(userId);

  if (!isAllowed(userId)) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Kamu Tidak Memiliki Akses Untuk Menggunakan Perintah Ini.

💡 Hubungi Owner Untuk Mendapatkan Akses Premium.`
    );
  }

  if (userStates[userId] || getQueueEntry(userIdStr)) {
    const entry = getQueueEntry(userIdStr);
    if (entry) {
      const qPos = getQueuePosition(userIdStr);
      return ctx.replyWithHTML(
`⚠️ <b>Kamu Sudah Punya Proses Aktif!</b>

🔢 Posisi Antrian: <b>#${qPos + 1}</b>
⏳ Tunggu Hingga Proses Sebelumnya Selesai.`
      );
    }
    return ctx.replyWithHTML(
`⚠️ <b>Kamu Sudah Punya Proses Aktif!</b>

📤 Kirim File <b>ZIP</b> Proyek Kamu Untuk Lanjut Masuk Antrian.`
    );
  }

  const username = ctx.from.username || ctx.from.first_name?.replace(/\s+/g, '') || `user${userId}`;
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  const folderName = `${username}-${random}`;

  const createMsg = await ctx.replyWithHTML(
`🔧 <b>Menyiapkan Folder Aplikasi...</b>

📂 <b>Nama Folder:</b> <code>${folderName}</code>`
  );

  try {
    await octokit.repos.createForAuthenticatedUser({
      name: folderName,
      private: false,
      auto_init: false,
    });
  } catch (err) {
    await editMsg(ctx.chat.id, createMsg.message_id,
`❌ <b>Gagal Menyiapkan Folder!</b>

🔴 Error: <code>${err.message}</code>`
    );
    return;
  }

  userStates[userId] = { repoName: folderName, step: 'awaiting_zip' };

  await editMsg(ctx.chat.id, createMsg.message_id,
`✅ <b>Folder Aplikasi Berhasil Dibuat!</b>

📂 <b>Nama Folder:</b> <code>${folderName}</code>

📤 Sekarang Kirim File <b>ZIP</b> Proyek Android Kamu!
⚠️ Kamu Baru Masuk Antrian Setelah ZIP Berhasil Dikirim.`
  );
});

bot.on('document', (ctx) => {
  const userId = ctx.from.id;
  const userIdStr = String(userId);
  const state = userStates[userId];
  const username = ctx.from.username || ctx.from.first_name || String(userId);

  if (!state || state.step !== 'awaiting_zip') return;
  if (!isAllowed(userId)) return;

  const doc = ctx.message.document;
  const fileName = doc.file_name || '';
  const fileSizeMB = doc.file_size ? (doc.file_size / (1024 * 1024)).toFixed(2) : '?';

  console.log(`\n📥 [DOCUMENT RECEIVED]`);
  console.log(`   👤 Username  : @${username} (${userId})`);
  console.log(`   📄 File Name : ${fileName}`);
  console.log(`   📦 File Size : ${fileSizeMB} MB`);
  console.log(`   📂 Folder   : ${state.repoName}`);
  console.log(`   🕐 Time     : ${new Date().toLocaleString()}`);

  if (!fileName.toLowerCase().endsWith('.zip')) {
    console.log(`   ❌ Ditolak: Bukan File ZIP`);
    ctx.replyWithHTML(
`⚠️ <b>Format Tidak Valid!</b>

📁 Hanya File <b>ZIP</b> Yang Diterima!
📤 Kirim Ulang File Dengan Format <code>.zip</code>`
    );
    return;
  }

  const MAX_TG_DOWNLOAD = 20 * 1024 * 1024;
  if (doc.file_size && doc.file_size > MAX_TG_DOWNLOAD) {
    console.log(`   ❌ Ditolak: File Terlalu Besar (${fileSizeMB} MB > 20 MB), Skip Antrian`);
    ctx.replyWithHTML(
`❌ <b>File Terlalu Besar!</b>

📦 Ukuran ZIP Kamu: <b>${fileSizeMB} MB</b>
⚠️ Telegram Bot Hanya Bisa Download File ≤ <b>20 MB</b>

🔁 Kamu Tidak Masuk Antrian. Kompres Ulang ZIP Kamu Lalu Kirim Ulang.`
    );
    return;
  }

  buildQueue.push({
    userId: userIdStr,
    chatId: ctx.chat.id,
    username,
    repoName: state.repoName,
    fileId: doc.file_id,
    fileName,
    notifyWhenStarted: false,
  });
  userStates[userId].step = 'zip_received';

  const qPos = getQueuePosition(userIdStr);

  if (qPos === 0 && !isProcessing) {
    console.log(`   ✅ Giliran Langsung, Memulai Build...`);
    ctx.replyWithHTML(
`📦 <b>ZIP Berhasil Diterima!</b>

📄 <b>File:</b> <code>${fileName}</code>
📂 <b>Nama Folder:</b> <code>${state.repoName}</code>

🚀 Build Langsung Dimulai...`
    );
  } else {
    console.log(`   📦 ZIP Diterima, Masuk Antrian #${qPos + 1}`);
    ctx.replyWithHTML(
`📦 <b>ZIP Berhasil Diterima & Masuk Antrian!</b>

📄 <b>File:</b> <code>${fileName}</code>
📂 <b>Nama Folder:</b> <code>${state.repoName}</code>
🔢 <b>Posisi Antrian:</b> <b>#${qPos + 1}</b>

⏳ ZIP Kamu Akan Otomatis Diupload & Dibuild Begitu Antrian Sebelum Kamu Selesai. Tidak Perlu Kirim Ulang.`
    );
  }

  processQueue().catch((err) => {
    console.error(`\n❌ [PROCESS QUEUE CRASH] User: @${username} (${userId})`);
    console.error(`   Error: ${err.message}`);
    console.error(err.stack);
    bot.telegram.sendMessage(ctx.chat.id,
`❌ <b>Terjadi Kesalahan Internal!</b>

🔴 <b>Error:</b> <code>${err.message}</code>`,
      { parse_mode: 'HTML' }
    ).catch(() => {});
  });
});

const pendingPhotos = {};

bot.on('photo', async (ctx) => {
  const userId = ctx.from.id;
  if (!isAllowed(userId)) return;

  const photos = ctx.message.photo;
  const photo  = photos[photos.length - 1];
  pendingPhotos[userId] = {
    fileId: photo.file_id,
    msgId: ctx.message.message_id,
    chatId: ctx.chat.id,
    ts: Date.now(),
  };
});

bot.command('webtoapp', async (ctx) => {
  const userId = ctx.from.id;

  if (!isAllowed(userId)) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Kamu Tidak Memiliki Akses Untuk Menggunakan Perintah Ini.

💡 Hubungi Owner Untuk Mendapatkan Akses Premium.`
    );
  }

  const raw  = ctx.message.text.replace(/^\/webtoapp\s*/i, '').trim();
  const parts = raw.split(',').map(p => p.trim());

  if (parts.length < 4 || parts.some((p, i) => i < 3 && !p)) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📌 <b>Cara pakai:</b>
1️⃣ Kirim foto icon app
2️⃣ Reply foto itu dengan:
<code>/webtoapp url,nama app,package,versi</code>

📝 <b>Contoh:</b>
<code>/webtoapp https://dashboard.pegasusx.com,Pegasus App,com.pegasus.app,1.0</code>`
    );
  }

  const [webUrl, appName, packageName, versionName] = parts;

  if (!/^https?:\/\/.+\..+/.test(webUrl)) {
    return ctx.replyWithHTML(`❌ <b>URL tidak valid!</b> Harus diawali <code>http://</code> atau <code>https://</code>`);
  }

  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,}$/.test(packageName)) {
    return ctx.replyWithHTML(`❌ <b>Package name tidak valid!</b>\nFormat: <code>com.namaapp.sesuatu</code>`);
  }

  if (!appName || appName.length < 2 || appName.length > 30) {
    return ctx.replyWithHTML(`❌ <b>Nama app tidak valid!</b> Minimal 2, maksimal 30 karakter.`);
  }

  if (!versionName || !/^[\d.]+$/.test(versionName)) {
    return ctx.replyWithHTML(`❌ <b>Versi tidak valid!</b>\nContoh: <code>1.0</code> atau <code>2.1.3</code>`);
  }

  const replyTo = ctx.message.reply_to_message;
  let iconFileId = null;

  if (replyTo && replyTo.photo) {
    const photos = replyTo.photo;
    iconFileId = photos[photos.length - 1].file_id;
  } else if (pendingPhotos[userId]) {

    const pending = pendingPhotos[userId];
    const ageMin  = (Date.now() - pending.ts) / 60000;
    if (ageMin <= 10) {
      iconFileId = pending.fileId;
    } else {
      delete pendingPhotos[userId];
    }
  }

  const isRawGithub = /^https:\/\/raw\.githubusercontent\.com\/.+\.(txt|json)$/i.test(webUrl)
                   || /^https:\/\/raw\.github\.com\/.+\.(txt|json)$/i.test(webUrl);
  const urlMode = isRawGithub ? 'remote' : 'direct';

  const state = {
    flow: 'webtoapp',
    webUrl,
    appName,
    packageName,
    versionName,
    urlMode,
    iconFileId,
  };

  delete pendingPhotos[userId];

  await runWebToApp(ctx.chat.id, userId, state);
});

async function runWebToApp(chatId, userId, state) {
  const username  = (await bot.telegram.getChat(chatId).catch(() => null))?.username || `user${userId}`;
  const random    = Math.random().toString(36).substring(2, 8).toUpperCase();
  const repoName  = `WEB2APK-${random}`;

  const statusMsg = await bot.telegram.sendMessage(chatId,
`🔧 <b>Memproses Web To APK...</b>

🌐 <b>URL:</b> <code>${state.webUrl}</code>
📱 <b>App:</b> <code>${state.appName}</code>
📦 <b>Package:</b> <code>${state.packageName}</code>

${loadingBar(5)} Menyiapkan Folder...`, { parse_mode: 'HTML' }
  );

  const edit = (txt) => editMsg(chatId, statusMsg.message_id, txt);

  try {
    await octokit.repos.createForAuthenticatedUser({
      name: repoName,
      private: false,
      auto_init: true,
    });

    await new Promise(r => setTimeout(r, 3000));

    await edit(
`🔧 <b>Memproses Web To APK...</b>

🌐 <b>URL:</b> <code>${state.webUrl}</code>
📱 <b>App:</b> <code>${state.appName}</code>
📦 <b>Package:</b> <code>${state.packageName}</code>

${loadingBar(20)} Mengupload Workflow...`
    );

    const ymlPath  = path.join(__dirname, '.github', 'workflows', 'webview-build.yml');
    const ymlContent = fs.readFileSync(ymlPath).toString('base64');
    await uploadToGitHub(GH_USERNAME, repoName,
      '.github/workflows/webview-build.yml', ymlContent, 'Add WebView build workflow');

    await new Promise(r => setTimeout(r, 5000));

    await edit(
`🔧 <b>Memproses Web To APK...</b>\n\n🌐 <b>URL:</b> <code>${state.webUrl}</code>\n📱 <b>App:</b> <code>${state.appName}</code>\n📦 <b>Package:</b> <code>${state.packageName}</code>\n\n${loadingBar(30)} Mengupload Template Files...`
    );

    const templatesDir = path.join(__dirname, 'templates');
    const templateFiles = [];

    function walkTemplates(dir, base) {
      for (const item of fs.readdirSync(dir)) {
        const full = path.join(dir, item);
        const rel  = base ? `${base}/${item}` : item;
        if (fs.statSync(full).isDirectory()) {
          walkTemplates(full, rel);
        } else {
          templateFiles.push({ full, rel });
        }
      }
    }
    walkTemplates(templatesDir, 'templates');

    for (const file of templateFiles) {
      const content = fs.readFileSync(file.full).toString('base64');
      await uploadToGitHub(GH_USERNAME, repoName,
        file.rel, content, `Add template ${file.rel}`);
    }

    if (state.iconFileId) {
      await edit(
`🔧 <b>Memproses Web To APK...</b>

${loadingBar(35)} Mengupload Icon...`
      );
      try {
        const iconLink = await bot.telegram.getFileLink(state.iconFileId);
        const iconResp = await axios.get(iconLink.href, { responseType: 'arraybuffer' });
        const iconB64  = Buffer.from(iconResp.data).toString('base64');
        await uploadToGitHub(GH_USERNAME, repoName,
          'icon.png', iconB64, 'Add app icon');
      } catch (e) {
        console.warn('⚠️ Gagal Upload Icon, Lanjut Tanpa Icon:', e.message);
      }
    }

    await edit(
`🔧 <b>Memproses Web To APK...</b>

${loadingBar(50)} Memulai Proses Build...`
    );

    let dispatched = false;
    for (let i = 0; i < 18; i++) {
      await new Promise(r => setTimeout(r, 5000));
      try {
        await octokit.actions.createWorkflowDispatch({
          owner: GH_USERNAME,
          repo: repoName,
          workflow_id: 'webview-build.yml',
          ref: 'main',
          inputs: {
            web_url: state.webUrl,
            app_name: state.appName,
            package_name: state.packageName,
            url_mode: state.urlMode || 'direct',
            version_name: state.versionName || '1.0',
          },
        });
        dispatched = true;
        break;
      } catch (e) {
        console.log(`   ⏳ Dispatch attempt ${i + 1}/18: ${e.message}`);
      }
    }

    if (!dispatched) {
      await edit(`❌ <b>Gagal Memulai Build!</b>\n\nGitHub tidak bisa menerima dispatch setelah 90 detik.`);
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    await edit(
`⚙️ <b>Build Sedang Berjalan...</b>

🌐 <b>URL:</b> <code>${state.webUrl}</code>
📱 <b>App:</b> <code>${state.appName}</code>
📦 <b>Package:</b> <code>${state.packageName}</code>

${loadingBar(55)} Actions Sedang Compile...
⏳ Estimasi: <b>1-5 Menit</b>`
    );

    const buildResult = await pollBuild(GH_USERNAME, repoName, 15);

    if (!buildResult) {
      await edit(`❌ <b>Build Timeout!</b>\n\n⏰ Build Melebihi Batas Waktu 15 Menit.`);
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    if (buildResult.conclusion !== 'success') {
      let logHint = '';
      if (buildResult.runId) {
        const logs = await getBuildLogs(GH_USERNAME, repoName, buildResult.runId);
        if (logs) {
          saveErrorLog(chatId, repoName, logs.full);
          logHint = `\n\n💡 Gunakan <code>/log</code> untuk minta log lengkap jika perlu.`;
        }
      }
      await edit(
`❌ <b>Build Gagal!</b>

📋 <b>Status:</b> <code>${buildResult.conclusion}</code>${logHint}`
      );
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    await edit(
`✅ <b>Build Berhasil!</b>

${loadingBar(90)} Mengunduh APK...`
    );

    const { data: artifacts } = await octokit.actions.listWorkflowRunArtifacts({
      owner: GH_USERNAME,
      repo: repoName,
      run_id: buildResult.runId,
    });

    if (!artifacts.artifacts.length) {
      await edit(`❌ <b>APK Tidak Ditemukan!</b>\n\nArtifact kosong setelah build.`);
      delete userStates[userId];
      deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
      return;
    }

    const artifact     = artifacts.artifacts[0];
    const downloadResp = await octokit.actions.downloadArtifact({
      owner: GH_USERNAME,
      repo: repoName,
      artifact_id: artifact.id,
      archive_format: 'zip',
    });

    await edit(`${loadingBar(95)} Memproses File APK...`);

    const artifactBuf  = await axios.get(downloadResp.url, {
      responseType: 'arraybuffer',
      maxRedirects: 5,
      headers: { Authorization: `token ${GH_TOKEN}` },
    }).then(r => r.data).catch(async () => {
      const loc = downloadResp.url;
      const r2  = await axios.get(loc, { responseType: 'arraybuffer', maxRedirects: 10 });
      return r2.data;
    });

    const tmpDir   = path.join(TMP_BASE, `w2a_${userId}_${Date.now()}`);
    fs.mkdirSync(tmpDir, { recursive: true });
    const zipPath  = path.join(tmpDir, 'artifact.zip');
    fs.writeFileSync(zipPath, Buffer.from(artifactBuf));

    const zip    = new AdmZip(zipPath);
    const apkEntry = zip.getEntries().find(e => e.entryName.endsWith('.apk'));

    let apkPath;
    if (apkEntry) {
      apkPath = path.join(tmpDir, apkEntry.entryName);
      zip.extractEntryTo(apkEntry, tmpDir, false, true);
    } else {
      apkPath = zipPath;
    }

    const apkSizeMB = (fs.statSync(apkPath).size / (1024 * 1024)).toFixed(2);
    const safeName  = state.appName.replace(/[^a-zA-Z0-9\-_]/g, '-');

    await edit(`${loadingBar(98)} Mengirim APK...`);

    await bot.telegram.sendDocument(chatId, {
      source: fs.createReadStream(apkPath),
      filename: `${safeName}.apk`,
    }, {
      caption:
`✅ <b>Web To APK Selesai!</b>

🌐 <b>URL:</b> <code>${state.webUrl}</code>
📱 <b>App:</b> <code>${state.appName}</code>
📦 <b>Package:</b> <code>${state.packageName}</code>
🔢 <b>Versi:</b> <code>${state.versionName || '1.0'}</code>
📦 <b>Ukuran:</b> <code>${apkSizeMB} MB</code>

🎉 APK Siap Diinstall!`,
      parse_mode: 'HTML',
    });

    await edit(`✅ <b>APK Berhasil Dikirim!</b>\n\n📱 <b>${state.appName}</b> Sudah Siap!`);

    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (_) {}

    deleteRepoDelayed(chatId, repoName, 5).catch(() => {});

  } catch (err) {
    console.error(`❌ [WEBTOAPP ERROR] User: ${userId}`, err.message);
    saveErrorLog(chatId, repoName, `${err.message}\n\n${err.stack || ''}`);
    await edit(
`❌ <b>Terjadi Kesalahan!</b>

🔴 <code>${err.message}</code>

💡 Gunakan <code>/log</code> untuk minta log lengkap jika perlu.`
    );
    deleteRepoDelayed(chatId, repoName, 5).catch(() => {});
  }

  delete userStates[userId];
}

bot.command('bc', async (ctx) => {
  if (String(ctx.from.id) !== config.OwnerId) {
    return ctx.replyWithHTML(
`🚫 <b>Akses Ditolak!</b>

❌ Perintah Ini Hanya Untuk Owner.`
    );
  }

  const pesan = ctx.message.text.replace(/^\/bc\s*/i, '').trim();

  if (!pesan) {
    return ctx.replyWithHTML(
`⚠️ <b>Format Salah!</b>

📝 Gunakan: <code>/bc [pesan]</code>

💡 <b>Contoh:</b>
<code>/bc Bot akan maintenance jam 12 malam!</code>`
    );
  }

  const targets = [...new Set(premiumUsers.map(String))];

  if (!targets.length) {
    return ctx.replyWithHTML(
`📋 <b>Daftar Premium Kosong!</b>

😔 Tidak Ada User Premium Yang Bisa Dikirimi Pesan.`
    );
  }

  const progressMsg = await ctx.replyWithHTML(
`📢 <b>Memulai Broadcast...</b>

👥 Total Target: <b>${targets.length}</b> User Premium
⏳ Harap Tunggu...`
  );

  let sukses = 0;
  let gagal = 0;

  for (const id of targets) {
    try {
      await bot.telegram.sendMessage(id,
`📢 <b>Pesan Dari Owner</b>

${pesan}

<i>— Ryuichi Builder Bot</i>`,
        { parse_mode: 'HTML' }
      );
      sukses++;
    } catch (err) {
      console.error(`⚠️ Gagal Kirim BC Ke ${id}:`, err.message);
      gagal++;
    }
  }

  await editMsg(ctx.chat.id, progressMsg.message_id,
`✅ <b>Broadcast Selesai!</b>

📨 <b>Pesan:</b>
<blockquote>${pesan}</blockquote>

📊 <b>Hasil:</b>
✅ Berhasil: <b>${sukses}</b> User
❌ Gagal: <b>${gagal}</b> User
👥 Total: <b>${targets.length}</b> User`
  );
});

bot.catch((err, ctx) => {
  console.error('❌ Bot Error:', err.message);
});

async function broadcastOnlineNotice() {
  const targets = new Set([config.OwnerId, ...premiumUsers.map(String)]);
  for (const id of targets) {
    try {
      await bot.telegram.sendMessage(id, 'Bot Telah Online Kembali ✅');
    } catch (err) {
      console.error(`⚠️ Gagal Kirim Notif Online Ke ${id}:`, err.message);
    }
  }
}

bot.launch();

bot.telegram.getMe()
  .then(async () => {
    BOT_START_TIME = Math.floor(Date.now() / 1000);
    console.log('🦅 Pegasus-X Builder Bot Berjalan!');
    console.log(`\n⣿⣿⣿⣿⣿⣿⣧⠻⣿⣿⠿⠿⠿⢿⣿⠟⣼⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⠟⠃⠁⠀⠀⠀⠀⠀⠀⠘⠻⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⡿⠃⠀⣴⡄⠀⠀⠀⠀⠀⣴⡆⠀⠘⢿⣿⣿⣿⣿
⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿
⣿⠿⢿⣿⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⣿⡿⠿⣿
⡇⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⢸
⡇⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⢸
⡇⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⢸
⡇⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⢸
⣧⣤⣤⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣤⣤⣼
⣿⣿⣿⣿⣶⣤⡄⠀⠀⠀⣤⣤⣤⠀⠀⠀⢠⣤⣴⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⣿⣿⣿⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣤⣤⣴⣿⣿⣿⣦⣤⣤⣾⣿⣿⣿⣿⠀⠀`);
    broadcastOnlineNotice().catch(err => console.error('❌ Gagal Broadcast Online:', err.message));
  })
  .catch(err => console.error('❌ Gagal Menjalankan Bot:', err));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
