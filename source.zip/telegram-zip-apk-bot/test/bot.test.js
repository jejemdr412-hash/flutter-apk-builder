'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const yazl = require('yazl');
const { safeExtract, findAndroidProject, zipEntryPath, buildEnvironment } = require('../bot');

function makeZip(entries) {
  return new Promise((resolve, reject) => {
    const zip = new yazl.ZipFile();
    const chunks = [];
    zip.outputStream.on('data', (chunk) => chunks.push(chunk));
    zip.outputStream.on('error', reject);
    zip.outputStream.on('end', () => resolve(Buffer.concat(chunks)));
    for (const [name, data] of entries) zip.addBuffer(Buffer.from(data), name);
    zip.end();
  });
}

async function withTempDir(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zip-apk-test-'));
  try { await fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

test('valid ZIP extracts safely and Android project is discovered', async () => {
  await withTempDir(async (dir) => {
    const zipPath = path.join(dir, 'sample.zip');
    const output = path.join(dir, 'out');
    fs.mkdirSync(output);
    fs.writeFileSync(zipPath, await makeZip([
      ['project/settings.gradle', 'rootProject.name = "sample"'],
      ['project/gradlew', '#!/bin/sh\nexit 0\n'],
      ['project/app/src/main/AndroidManifest.xml', '<manifest />'],
    ]));

    const result = await safeExtract(zipPath, output, { maxUnpackedMb: 1, maxFiles: 10 });
    assert.equal(result.count, 3);
    assert.equal(fs.readFileSync(path.join(output, 'project', 'settings.gradle'), 'utf8'), 'rootProject.name = "sample"');
    assert.equal(findAndroidProject(output), path.join(output, 'project'));
  });
});

test('unsafe ZIP path forms are rejected', () => {
  for (const name of ['../outside.txt', '/absolute.txt', 'C:/outside.txt', 'folder\\outside.txt', 'folder/../outside.txt']) {
    assert.throws(() => zipEntryPath(name), /path|tidak aman/i, name);
  }
  assert.deepEqual(zipEntryPath('folder/file.txt'), { parts: ['folder', 'file.txt'], isDirectory: false });
  assert.deepEqual(zipEntryPath('folder/'), { parts: ['folder'], isDirectory: true });
});

test('ZIP entry limits are enforced', async () => {
  await withTempDir(async (dir) => {
    const zipPath = path.join(dir, 'many.zip');
    const output = path.join(dir, 'out');
    fs.mkdirSync(output);
    fs.writeFileSync(zipPath, await makeZip([['one.txt', '1'], ['two.txt', '2']]));
    await assert.rejects(safeExtract(zipPath, output, { maxUnpackedMb: 1, maxFiles: 1 }), /Jumlah file ZIP/);
  });
});

test('Gradle environment does not include the Telegram bot token', () => {
  const previous = process.env.TELEGRAM_BOT_TOKEN;
  process.env.TELEGRAM_BOT_TOKEN = 'do-not-pass-to-gradle';
  try {
    const env = buildEnvironment();
    assert.equal(Object.hasOwn(env, 'TELEGRAM_BOT_TOKEN'), false);
    assert.equal(env.LANG, 'C.UTF-8');
  } finally {
    if (previous === undefined) delete process.env.TELEGRAM_BOT_TOKEN;
    else process.env.TELEGRAM_BOT_TOKEN = previous;
  }
});
