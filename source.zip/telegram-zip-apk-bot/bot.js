'use strict';

require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn } = require('node:child_process');
const { Transform } = require('node:stream');
const { pipeline } = require('node:stream/promises');
const { Readable } = require('node:stream');
const yauzl = require('yauzl');
const { Bot, InputFile } = require('grammy');

const LOG_LEVEL = (process.env.LOG_LEVEL || 'INFO').toUpperCase();
const MAX_LOG_CHARS = 3500;
let buildActive = false;

function positiveInteger(name, fallback) {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === '') return fallback;
  if (!/^\d+$/.test(raw.trim())) throw new Error(`${name} harus berupa bilangan bulat positif.`);
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new Error(`${name} harus berupa bilangan bulat positif yang valid.`);
  }
  return value;
}

const CONFIG = {
  token: (process.env.TELEGRAM_BOT_TOKEN || '').trim(),
  ownerIds: new Set((process.env.TELEGRAM_OWNER_IDS || '')
    .split(',').map((value) => value.trim()).filter((value) => /^\d+$/.test(value))),
  maxZipMb: positiveInteger('MAX_ZIP_MB', 20),
  maxUnpackedMb: positiveInteger('MAX_UNPACKED_MB', 600),
  maxFiles: positiveInteger('MAX_FILES', 4000),
  buildTimeoutSec: positiveInteger('BUILD_TIMEOUT_SEC', 1800),
};

function log(level, message, error) {
  const levels = ['DEBUG', 'INFO', 'WARN', 'ERROR'];
  if (levels.indexOf(level) < levels.indexOf(LOG_LEVEL)) return;
  const suffix = error ? ` ${error.stack || error.message || error}` : '';
  console.log(`${new Date().toISOString()} ${level} zip-apk-bot: ${message}${suffix}`);
}

function isAuthorized(ctx) {
  return ctx.chat?.type === 'private'
    && ctx.from
    && CONFIG.ownerIds.has(String(ctx.from.id));
}

async function deny(ctx) {
  if (ctx.msg) {
    await ctx.reply('Akses ditolak. Bot ini hanya menerima pesan privat dari ID yang diizinkan.');
  }
}

function zipEntryPath(name) {
  if (typeof name !== 'string' || name.length === 0 || name.includes('\0') || name.includes('\\')) {
    throw new Error('ZIP berisi nama file/path yang tidak aman.');
  }
  if (name.startsWith('/') || /^[a-zA-Z]:/.test(name)) {
    throw new Error('ZIP berisi path absolut atau path traversal.');
  }
  const isDirectory = name.endsWith('/');
  const rawParts = name.split('/');
  if (isDirectory) rawParts.pop();
  if (rawParts.length === 0 || rawParts.some((part) => !part || part === '.' || part === '..')) {
    throw new Error('ZIP berisi path absolut atau path traversal.');
  }
  return { parts: rawParts, isDirectory };
}

function safeExtract(zipPath, destination, limits = {}) {
  const maxUnpacked = (limits.maxUnpackedMb ?? CONFIG.maxUnpackedMb) * 1024 * 1024;
  const maxFiles = limits.maxFiles ?? CONFIG.maxFiles;

  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, {
      lazyEntries: true,
      autoClose: false,
      decodeStrings: true,
      validateEntrySizes: true,
      strictFileNames: true,
    }, (openError, archive) => {
      if (openError) {
        reject(new Error(`ZIP tidak dapat dibaca: ${openError.message}`));
        return;
      }

      let settled = false;
      let count = 0;
      let totalSize = 0;
      const seen = new Set();
      const root = path.resolve(destination);

      const fail = (error) => {
        if (settled) return;
        settled = true;
        try { archive.close(); } catch { /* arsip mungkin sudah tertutup */ }
        reject(error);
      };

      archive.on('error', fail);
      archive.on('end', () => {
        if (settled) return;
        settled = true;
        resolve({ count, totalSize });
      });
      archive.on('entry', (entry) => {
        (async () => {
          count += 1;
          if (count > maxFiles) throw new Error(`Jumlah file ZIP melebihi batas ${maxFiles}.`);

          const { parts, isDirectory: nameIsDirectory } = zipEntryPath(entry.fileName);
          const canonicalName = parts.join('/');
          if (seen.has(canonicalName)) throw new Error('ZIP berisi nama file duplikat.');
          seen.add(canonicalName);

          const mode = (entry.externalFileAttributes >>> 16) & 0xffff;
          const fileType = mode & 0o170000;
          if (fileType === 0o120000) throw new Error('ZIP berisi symbolic link; jenis file ini ditolak.');
          if (fileType && fileType !== 0o100000 && fileType !== 0o040000) {
            throw new Error('ZIP berisi jenis file khusus yang tidak didukung.');
          }
          if (entry.generalPurposeBitFlag & 0x1) throw new Error('ZIP terenkripsi tidak didukung.');

          const isDirectory = nameIsDirectory || fileType === 0o040000;
          const size = entry.uncompressedSize;
          const compressedSize = entry.compressedSize;
          if (!Number.isSafeInteger(size) || size < 0 || size > maxUnpacked) {
            throw new Error('Ada file ZIP yang melewati batas ukuran ekstraksi.');
          }
          totalSize += size;
          if (totalSize > maxUnpacked) {
            throw new Error(`Ukuran total setelah ekstrak melebihi ${Math.floor(maxUnpacked / (1024 * 1024))} MB.`);
          }
          if (size > 1_000_000 && compressedSize === 0) {
            throw new Error('ZIP memiliki rasio kompresi yang tidak wajar.');
          }
          if (compressedSize > 0 && size / compressedSize > 300) {
            throw new Error('ZIP memiliki rasio kompresi terlalu tinggi.');
          }

          const target = path.resolve(root, ...parts);
          const relative = path.relative(root, target);
          if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) {
            throw new Error('ZIP mencoba menulis di luar folder kerja.');
          }

          if (isDirectory) {
            fs.mkdirSync(target, { recursive: true, mode: 0o700 });
            archive.readEntry();
            return;
          }

          fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
          const readStream = await new Promise((resolveStream, rejectStream) => {
            archive.openReadStream(entry, (streamError, stream) => {
              if (streamError) rejectStream(streamError);
              else resolveStream(stream);
            });
          });
          let written = 0;
          const limiter = new Transform({
            transform(chunk, encoding, callback) {
              written += chunk.length;
              if (written > size || written > maxUnpacked) {
                callback(new Error('Ukuran hasil ekstraksi tidak sesuai batas.'));
              } else {
                callback(null, chunk);
              }
            },
          });
          await pipeline(readStream, limiter, fs.createWriteStream(target, { flags: 'wx', mode: 0o600 }));
          if (written !== size) throw new Error('ZIP rusak atau ukuran file tidak cocok.');
          archive.readEntry();
        })().catch(fail);
      });
      archive.readEntry();
    });
  });
}

function findAndroidProject(extracted) {
  const candidates = [];
  const skipped = new Set(['.git', '.gradle', 'build', 'node_modules']);

  function walk(current) {
    const relative = path.relative(extracted, current);
    const depth = relative ? relative.split(path.sep).length : 0;
    if (depth > 5) return;

    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }
    const names = new Set(entries.filter((entry) => entry.isFile()).map((entry) => entry.name));
    const hasSettings = names.has('settings.gradle') || names.has('settings.gradle.kts');
    if (names.has('gradlew') && hasSettings) candidates.push(current);

    if (depth === 5) return;
    for (const entry of entries) {
      if (entry.isDirectory() && !skipped.has(entry.name)) walk(path.join(current, entry.name));
    }
  }

  walk(extracted);
  candidates.sort((a, b) => {
    const depthA = path.relative(extracted, a).split(path.sep).filter(Boolean).length;
    const depthB = path.relative(extracted, b).split(path.sep).filter(Boolean).length;
    return depthA - depthB || a.localeCompare(b);
  });
  if (!candidates.length) {
    throw new Error('Tidak menemukan proyek Android Gradle. ZIP harus memuat gradlew dan settings.gradle atau settings.gradle.kts.');
  }
  return candidates[0];
}

function buildEnvironment() {
  const env = {
    PATH: process.env.PATH || '/usr/local/bin:/usr/bin:/bin',
    HOME: process.env.HOME || os.homedir() || '/tmp',
    LANG: 'C.UTF-8',
    LC_ALL: 'C.UTF-8',
    GRADLE_USER_HOME: process.env.GRADLE_USER_HOME || path.join(os.homedir(), '.gradle'),
  };
  for (const name of ['JAVA_HOME', 'ANDROID_HOME', 'ANDROID_SDK_ROOT']) {
    if (process.env[name]) env[name] = process.env[name];
  }
  return env;
}

function logTail(filePath) {
  try {
    const fd = fs.openSync(filePath, 'r');
    try {
      const size = fs.fstatSync(fd).size;
      const length = Math.min(size, 12_000);
      const buffer = Buffer.alloc(length);
      fs.readSync(fd, buffer, 0, length, Math.max(0, size - length));
      return buffer.toString('utf8').slice(-MAX_LOG_CHARS).trim() || '(Log build kosong.)';
    } finally {
      fs.closeSync(fd);
    }
  } catch {
    return 'Log build tidak tersedia.';
  }
}

function killBuild(child) {
  if (!child.pid) return;
  try {
    if (process.platform !== 'win32') process.kill(-child.pid, 'SIGTERM');
    else child.kill('SIGTERM');
  } catch { /* proses bisa sudah berhenti */ }
  const forceTimer = setTimeout(() => {
    try {
      if (process.platform !== 'win32') process.kill(-child.pid, 'SIGKILL');
      else child.kill('SIGKILL');
    } catch { /* proses bisa sudah berhenti */ }
  }, 5000);
  forceTimer.unref();
}

function runGradle(project, logPath) {
  const gradlew = path.join(project, 'gradlew');
  return new Promise((resolve, reject) => {
    const logFd = fs.openSync(logPath, 'w', 0o600);
    let timedOut = false;
    let spawnError = null;
    let child;
    try {
      child = spawn(gradlew, ['--no-daemon', '--console=plain', 'assembleDebug'], {
        cwd: project,
        env: buildEnvironment(),
        stdio: ['ignore', logFd, logFd],
        detached: process.platform !== 'win32',
        shell: false,
      });
    } catch (error) {
      fs.closeSync(logFd);
      reject(error);
      return;
    }

    const timeout = setTimeout(() => {
      timedOut = true;
      killBuild(child);
    }, CONFIG.buildTimeoutSec * 1000);

    child.once('error', (error) => { spawnError = error; });
    child.once('close', (code) => {
      clearTimeout(timeout);
      fs.closeSync(logFd);
      if (timedOut) {
        reject(new Error(`Build melewati batas waktu ${Math.floor(CONFIG.buildTimeoutSec / 60)} menit.`));
      } else if (spawnError) {
        reject(spawnError);
      } else if (code !== 0) {
        reject(new Error(`Build gagal. Potongan log terakhir:\n\n${logTail(logPath)}`));
      } else {
        resolve();
      }
    });
  });
}

function findDebugApks(project) {
  const found = [];
  const skipped = new Set(['.git', '.gradle', 'node_modules']);
  function walk(current) {
    let entries;
    try { entries = fs.readdirSync(current, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      const item = path.join(current, entry.name);
      if (entry.isDirectory() && !skipped.has(entry.name)) walk(item);
      else if (entry.isFile() && entry.name.toLowerCase().endsWith('.apk')) {
        const parts = path.relative(project, item).split(path.sep);
        const outputIndex = parts.indexOf('outputs');
        if (outputIndex !== -1 && parts[outputIndex + 1] === 'apk' && parts.slice(outputIndex + 2, -1).includes('debug')) {
          found.push(item);
        }
      }
    }
  }
  walk(project);
  return found;
}

async function downloadTelegramFile(bot, fileId, destination) {
  const file = await bot.api.getFile(fileId);
  if (!file.file_path) throw new Error('Telegram tidak memberikan lokasi file unduhan.');
  const response = await fetch(`https://api.telegram.org/file/bot${CONFIG.token}/${file.file_path}`);
  if (!response.ok || !response.body) throw new Error(`Unduhan dari Telegram gagal (HTTP ${response.status}).`);
  const maxBytes = CONFIG.maxZipMb * 1024 * 1024;
  let downloaded = 0;
  const limiter = new Transform({
    transform(chunk, encoding, callback) {
      downloaded += chunk.length;
      if (downloaded > maxBytes) callback(new Error(`ZIP melewati batas ${CONFIG.maxZipMb} MB.`));
      else callback(null, chunk);
    },
  });
  await pipeline(Readable.fromWeb(response.body), limiter, fs.createWriteStream(destination, { flags: 'wx', mode: 0o600 }));
}

async function setStatus(ctx, statusMessage, text) {
  await ctx.api.editMessageText(ctx.chat.id, statusMessage.message_id, text);
}

async function start(ctx) {
  if (!isAuthorized(ctx)) return deny(ctx);
  await ctx.reply(
    'Kirim ZIP proyek Android berbasis Gradle. Bot menjalankan assembleDebug dan mengirim APK debug jika berhasil.\n\n'
    + 'ZIP harus memuat gradlew serta settings.gradle(.kts). Gunakan hanya proyek milik Anda atau sumber yang tepercaya.'
  );
}

async function handleZip(ctx) {
  if (!isAuthorized(ctx)) return deny(ctx);
  const message = ctx.msg;
  const document = message?.document;
  if (!document || !document.file_name || !document.file_name.toLowerCase().endsWith('.zip')) {
    await ctx.reply('Kirim file dengan ekstensi .zip.');
    return;
  }
  if (document.file_size && document.file_size > CONFIG.maxZipMb * 1024 * 1024) {
    await ctx.reply(`ZIP terlalu besar. Batas konfigurasi: ${CONFIG.maxZipMb} MB.`);
    return;
  }
  if (buildActive) {
    await ctx.reply('Bot sedang membangun proyek lain. Coba kirim lagi setelah selesai.');
    return;
  }

  buildActive = true;
  let statusMessage;
  try {
    statusMessage = await ctx.reply('ZIP diterima. Memeriksa proyek dan memulai build…');
    const workspace = fs.mkdtempSync(path.join(os.tmpdir(), 'zip-apk-build-'));
    try {
      const zipPath = path.join(workspace, 'upload.zip');
      const extractDir = path.join(workspace, 'source');
      fs.mkdirSync(extractDir, { mode: 0o700 });

      await downloadTelegramFile(ctx.api, document.file_id, zipPath);
      await setStatus(ctx, statusMessage, 'Memeriksa dan mengekstrak ZIP dengan aman…');
      await safeExtract(zipPath, extractDir);
      const project = findAndroidProject(extractDir);
      const gradlew = path.join(project, 'gradlew');
      fs.chmodSync(gradlew, fs.statSync(gradlew).mode | 0o100);

      await setStatus(ctx, statusMessage, 'Menjalankan assembleDebug. Build bisa memerlukan beberapa menit…');
      const logPath = path.join(workspace, 'gradle-build.log');
      await runGradle(project, logPath);

      const apks = findDebugApks(project);
      if (!apks.length) {
        throw new Error(`Build selesai tetapi APK debug tidak ditemukan. Potongan log:\n\n${logTail(logPath)}`);
      }
      const apk = apks.find((file) => path.basename(file) === 'app-debug.apk') || apks[0];
      await ctx.replyWithDocument(new InputFile(apk, path.basename(apk)), {
        caption: `Build berhasil: ${path.basename(apk)}`,
      });
      await setStatus(ctx, statusMessage, 'Selesai. APK debug sudah dikirim di atas.');
    } finally {
      fs.rmSync(workspace, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
    }
  } catch (error) {
    log('INFO', `Build ditolak/gagal untuk user=${ctx.from.id}: ${error.message}`);
    let text = error.message || 'Kesalahan tidak diketahui.';
    if (text.length > 3800) text = text.slice(-3800);
    if (statusMessage) {
      try { await setStatus(ctx, statusMessage, `Tidak berhasil membuat APK.\n\n${text}`); }
      catch (editError) { log('WARN', 'Tidak dapat memperbarui status Telegram.', editError); }
    } else {
      await ctx.reply(`Tidak berhasil membuat APK.\n\n${text}`);
    }
  } finally {
    buildActive = false;
  }
}

async function main() {
  if (!CONFIG.token) throw new Error('Set TELEGRAM_BOT_TOKEN terlebih dahulu.');
  if (!CONFIG.ownerIds.size) throw new Error('Set TELEGRAM_OWNER_IDS dengan ID numerik Telegram yang diizinkan.');
  if (CONFIG.buildTimeoutSec < 60) throw new Error('BUILD_TIMEOUT_SEC minimal 60 detik.');

  const bot = new Bot(CONFIG.token);
  bot.command('start', start);
  bot.on('message:document', handleZip);
  bot.catch((error) => log('ERROR', 'Kesalahan saat memproses update Telegram.', error));
  log('INFO', `Bot aktif; allowlist berisi ${CONFIG.ownerIds.size} ID.`);
  await bot.start({ allowed_updates: ['message'] });
}

if (require.main === module) {
  main().catch((error) => {
    log('ERROR', error.message, error);
    process.exitCode = 1;
  });
}

module.exports = { safeExtract, findAndroidProject, findDebugApks, zipEntryPath, buildEnvironment };
