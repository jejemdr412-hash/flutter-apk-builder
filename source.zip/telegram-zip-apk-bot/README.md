# Bot Telegram: ZIP proyek Android → APK debug (Node.js)

Bot ini menerima ZIP berisi **proyek Android Gradle**, menjalankan `assembleDebug`, lalu mengirim APK debug yang dihasilkan kembali melalui Telegram. Bot tidak mengubah ZIP sembarang menjadi aplikasi: ZIP harus berisi kode sumber proyek Android yang dapat dibangun.

## Prasyarat

- Node.js 20 atau lebih baru.
- JDK yang sesuai dengan proyek (JDK 17 lazim untuk proyek Android modern).
- Android SDK, termasuk platform/build-tools yang dibutuhkan proyek dan lisensi SDK yang sudah diterima.
- Koneksi internet saat Gradle perlu mengunduh wrapper atau dependensi.
- Token bot Telegram dan ID numerik akun Telegram yang diizinkan.

`JAVA_HOME`, `ANDROID_HOME`, dan/atau `ANDROID_SDK_ROOT` harus tersedia di lingkungan proses bila instalasi tidak terdeteksi otomatis.

## Instalasi di Linux

```bash
cd telegram-zip-apk-bot
npm install
cp .env.example .env
```

Edit `.env`: isi `TELEGRAM_BOT_TOKEN` dan ganti `TELEGRAM_OWNER_IDS` dengan ID Telegram Anda. Kemudian jalankan bot:

```bash
npm start
```

Biarkan proses tetap berjalan. Buka bot di Telegram, kirim `/start`, lalu kirim ZIP proyek. ZIP perlu memuat `gradlew` serta `settings.gradle` atau `settings.gradle.kts` (maksimal 5 tingkat folder ke bawah). Bot membangun varian debug (`assembleDebug`). Biasanya APK berada di `app/build/outputs/apk/debug/` dan dikirim sebagai dokumen Telegram.

Untuk menjalankan pemeriksaan lokal:

```bash
npm test
```

## Batas dan pengaturan

Nilai bawaan ada di `.env.example`: ZIP maksimum 20 MB, hasil ekstrak maksimum 600 MB, maksimum 4.000 entri, dan timeout build 30 menit. Ubah bila perlu. Batas unduh file bot Telegram dapat bergantung pada konfigurasi Bot API yang digunakan.

## Keamanan penting

**Proses build menjalankan skrip Gradle dan kode dari ZIP.** Jangan mengirim ZIP dari orang tak dikenal dan jangan membuka bot ini untuk umum. Pertahankan allowlist `TELEGRAM_OWNER_IDS`, gunakan proyek tepercaya, dan jalankan bot pada mesin/VM khusus tanpa data atau kredensial penting. Bot membatasi ukuran, menolak path traversal, symbolic link, file ZIP terenkripsi, rasio kompresi berlebihan, dan jenis file khusus. Token bot tidak diteruskan ke proses Gradle. Namun, pembatas ini bukan pengganti sandbox OS/container untuk kode yang tidak tepercaya.

Jangan unggah atau commit `.env`. Jika token bot bocor, cabut dan buat ulang token melalui BotFather.
