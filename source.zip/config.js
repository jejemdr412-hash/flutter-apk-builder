module.exports = {
  BotToken: '8575217969:AAEAZ44AsswN8RHfvO3Uxid3MJrfsdE2QYw',
  GithubToken: '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',
  GithubUsername: 'Zal7Sex',
  GithubToken2: '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',
  GithubUsername2: 'ZalSex',
  OwnerId: '7242161057',
};
